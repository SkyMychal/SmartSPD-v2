import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Brain, 
  FileText, 
  MessageSquare, 
  Shield, 
  Zap, 
  Users, 
  CheckCircle, 
  ArrowRight,
  Sparkles,
  Database,
  Search,
  BarChart3
} from 'lucide-react';
import BeneSenseAILogo from '../assets/BeneSenseAILogo.png';
import SmartSPDLogo from '../assets/SmartSPDlogo.png';

const LandingPage = ({ onGetStarted }) => {
  const [hoveredFeature, setHoveredFeature] = useState(null);

  const features = [
    {
      icon: Brain,
      title: "Advanced AI Processing",
      description: "Powered by GPT-4 and advanced RAG technology for intelligent document understanding",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: FileText,
      title: "Smart Document Analysis",
      description: "Automatically processes SPD and BPS documents with intelligent chunking and context preservation",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: Search,
      title: "Hybrid Search Engine",
      description: "Combines semantic and keyword search for the most relevant and accurate results",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: Database,
      title: "Knowledge Graph Integration",
      description: "Structured benefit data with relationships for comprehensive understanding",
      color: "from-orange-500 to-red-500"
    },
    {
      icon: MessageSquare,
      title: "Natural Language Interface",
      description: "Ask questions in plain English and get precise, contextual answers",
      color: "from-indigo-500 to-purple-500"
    },
    {
      icon: BarChart3,
      title: "Analytics & Insights",
      description: "Track usage patterns and optimize your health plan communication",
      color: "from-teal-500 to-blue-500"
    }
  ];

  const benefits = [
    "Reduce customer service response time by 80%",
    "Improve accuracy of benefit information",
    "24/7 availability for plan members",
    "Seamless integration with existing systems",
    "HIPAA compliant and secure",
    "Multi-language support"
  ];

  const userTypes = [
    { title: "Customer Service Agents", description: "Get instant, accurate answers to member questions" },
    { title: "Plan Members", description: "Self-service access to benefit information" },
    { title: "HR Teams", description: "Streamline employee benefit communications" },
    { title: "Brokers & TPAs", description: "Enhanced client service capabilities" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <header className="relative z-10 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <img src={BeneSenseAILogo} alt="BeneSense AI" className="h-12 w-auto" />
              <div className="h-8 w-px bg-slate-300"></div>
              <img src={SmartSPDLogo} alt="SmartSPD" className="h-10 w-auto" />
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
                v2.0 Enhanced
              </Badge>
              <Button 
                onClick={onGetStarted}
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
              >
                Get Started
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-cyan-600/10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="flex justify-center mb-8">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="relative"
              >
                <div className="w-24 h-24 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center shadow-2xl">
                  <Sparkles className="h-12 w-12 text-white" />
                </div>
                <div className="absolute -inset-4 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-full blur-xl"></div>
              </motion.div>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-slate-900 via-blue-900 to-slate-900 bg-clip-text text-transparent mb-6">
              SmartSPD v2
            </h1>
            
            <p className="text-xl md:text-2xl text-slate-600 mb-4 max-w-3xl mx-auto">
              The Next Generation AI-Powered Health Plan Assistant
            </p>
            
            <p className="text-lg text-slate-500 mb-8 max-w-2xl mx-auto">
              Transform your health plan customer service with advanced RAG technology, 
              intelligent document processing, and natural language understanding.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                onClick={onGetStarted}
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
              >
                <Brain className="mr-2 h-5 w-5" />
                Experience SmartSPD v2
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-slate-300 hover:border-blue-500 hover:bg-blue-50 transition-all duration-300"
              >
                <FileText className="mr-2 h-5 w-5" />
                View Documentation
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-slate-900 mb-4">
              Powered by Advanced AI Technology
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              SmartSPD v2 combines cutting-edge AI with deep health insurance expertise 
              to deliver unparalleled accuracy and user experience.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                onHoverStart={() => setHoveredFeature(index)}
                onHoverEnd={() => setHoveredFeature(null)}
              >
                <Card className="h-full hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-0 shadow-lg">
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${feature.color} flex items-center justify-center mb-4 shadow-lg`}>
                      <feature.icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-xl font-semibold text-slate-900">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-slate-600 leading-relaxed">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl font-bold text-slate-900 mb-6">
                Transform Your Health Plan Operations
              </h2>
              <p className="text-xl text-slate-600 mb-8">
                SmartSPD v2 delivers measurable improvements to your customer service 
                operations while enhancing member satisfaction.
              </p>
              
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-center space-x-3"
                  >
                    <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0" />
                    <span className="text-slate-700 font-medium">{benefit}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="bg-white rounded-2xl shadow-2xl p-8 border border-slate-200">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <Badge variant="secondary">Live Demo</Badge>
                </div>
                
                <div className="space-y-4">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <p className="text-sm text-slate-600 mb-2">User Question:</p>
                    <p className="text-slate-900">"What's my copay for specialist visits?"</p>
                  </div>
                  
                  <div className="bg-blue-50 rounded-lg p-4">
                    <p className="text-sm text-blue-600 mb-2">SmartSPD v2 Response:</p>
                    <p className="text-slate-900">
                      "Based on your plan documents, specialist visits have a $30 copay 
                      for in-network providers. No referral required for your PPO plan."
                    </p>
                    <div className="flex items-center mt-3 space-x-2">
                      <Badge variant="outline" className="text-xs">95% Confidence</Badge>
                      <Badge variant="outline" className="text-xs">0.8s Response</Badge>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* User Types Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-slate-900 mb-4">
              Built for Every Stakeholder
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto">
              SmartSPD v2 serves the entire health plan ecosystem with tailored experiences 
              for each user type.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {userTypes.map((userType, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300 border border-slate-200">
                  <CardHeader>
                    <div className="flex items-center space-x-3 mb-2">
                      <Users className="h-6 w-6 text-blue-600" />
                      <CardTitle className="text-xl font-semibold text-slate-900">
                        {userType.title}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-slate-600 leading-relaxed">
                      {userType.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-cyan-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready to Transform Your Health Plan Experience?
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Join the next generation of health plan customer service with SmartSPD v2's 
              advanced AI capabilities.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={onGetStarted}
                size="lg"
                className="bg-white text-blue-600 hover:bg-blue-50 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105"
              >
                <Zap className="mr-2 h-5 w-5" />
                Start Your Demo
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                className="border-2 border-white text-white hover:bg-white hover:text-blue-600 transition-all duration-300"
              >
                <Shield className="mr-2 h-5 w-5" />
                Learn About Security
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <img src={BeneSenseAILogo} alt="BeneSense AI" className="h-8 w-auto opacity-80" />
              <span className="text-slate-400">×</span>
              <img src={SmartSPDLogo} alt="SmartSPD" className="h-6 w-auto opacity-80" />
            </div>
            
            <div className="text-center md:text-right">
              <p className="text-slate-400 text-sm">
                © 2024 BeneSense AI. All rights reserved.
              </p>
              <p className="text-slate-500 text-xs mt-1">
                SmartSPD v2.0 - Advanced AI Health Plan Assistant
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;


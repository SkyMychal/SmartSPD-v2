import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { 
  Send, 
  Bot, 
  User, 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  ThumbsUp,
  ThumbsDown,
  Copy,
  RefreshCw,
  Sparkles,
  MessageSquare,
  Settings,
  LogOut,
  Database,
  BarChart3
} from 'lucide-react';
import SmartSPDLogo from '../assets/SmartSPDlogo.png';

const ChatInterface = ({ user, healthPlan, onLogout }) => {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'bot',
      content: `Hello ${user?.name || 'there'}! I'm your SmartSPD v2 assistant. I can help you understand your ${healthPlan?.plan_name || 'health plan'} benefits. What would you like to know?`,
      timestamp: new Date(),
      confidence: 'high',
      sources: []
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  const suggestedQuestions = [
    "What are my deductibles and copays?",
    "What medical services are covered?",
    "How do I find in-network providers?",
    "What are my prescription drug benefits?",
    "What preventive care is covered at 100%?",
    "How do I submit a claim?"
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (messageText = inputValue) => {
    if (!messageText.trim() || isLoading) return;

    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: messageText.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Simulate API call to backend
      const response = await fetch('/api/chat/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query: messageText.trim(),
          health_plan_id: healthPlan?.id || 'demo-plan',
          user_id: user?.id || 'demo-user',
          session_id: sessionId
        })
      });

      if (response.ok) {
        const data = await response.json();
        
        const botMessage = {
          id: data.query_id || Date.now() + 1,
          type: 'bot',
          content: data.response || "I apologize, but I'm having trouble processing your request right now. Please try again.",
          timestamp: new Date(),
          confidence: data.confidence_level || 'medium',
          sources: data.sources || [],
          responseTime: data.response_time_ms
        };

        setMessages(prev => [...prev, botMessage]);
      } else {
        throw new Error('Failed to get response');
      }
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Fallback response for demo purposes
      const fallbackResponse = generateFallbackResponse(messageText);
      
      const botMessage = {
        id: Date.now() + 1,
        type: 'bot',
        content: fallbackResponse.content,
        timestamp: new Date(),
        confidence: fallbackResponse.confidence,
        sources: fallbackResponse.sources,
        responseTime: Math.floor(Math.random() * 1000) + 500
      };

      setMessages(prev => [...prev, botMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const generateFallbackResponse = (query) => {
    const queryLower = query.toLowerCase();
    
    if (queryLower.includes('deductible') || queryLower.includes('copay')) {
      return {
        content: `Based on your ${healthPlan?.plan_name || 'health plan'} documents, here are your cost-sharing details:\n\n• Annual Deductible: $1,500 (Individual) / $3,000 (Family)\n• Primary Care Copay: $25\n• Specialist Copay: $50\n• Emergency Room: $200 copay (waived if admitted)\n\nThese amounts apply to in-network providers. Out-of-network costs may be higher.`,
        confidence: 'high',
        sources: [
          { type: 'document', page_number: 12, section_title: 'Cost Sharing' },
          { type: 'knowledge_graph', benefit_name: 'Medical Benefits' }
        ]
      };
    }
    
    if (queryLower.includes('covered') || queryLower.includes('benefit')) {
      return {
        content: `Your ${healthPlan?.plan_name || 'health plan'} covers a comprehensive range of medical services including:\n\n• Preventive care (100% covered)\n• Primary and specialist care\n• Hospital and surgical services\n• Emergency and urgent care\n• Prescription drugs\n• Mental health and substance abuse treatment\n• Maternity and newborn care\n\nAll services are subject to your plan's deductible and copayment requirements when using in-network providers.`,
        confidence: 'high',
        sources: [
          { type: 'document', page_number: 8, section_title: 'Covered Services' },
          { type: 'document', page_number: 15, section_title: 'Benefits Summary' }
        ]
      };
    }
    
    if (queryLower.includes('provider') || queryLower.includes('network')) {
      return {
        content: `To find in-network providers for your ${healthPlan?.plan_name || 'health plan'}:\n\n1. Visit your plan's provider directory online\n2. Call the customer service number on your ID card\n3. Use the mobile app if available\n4. Contact your primary care physician for specialist referrals\n\nUsing in-network providers will save you money and ensure the highest level of coverage under your plan.`,
        confidence: 'medium',
        sources: [
          { type: 'document', page_number: 25, section_title: 'Provider Network' }
        ]
      };
    }
    
    return {
      content: `I understand you're asking about "${query}". While I don't have specific information about this topic in your current plan documents, I recommend:\n\n• Checking your Summary Plan Description (SPD)\n• Contacting your plan administrator\n• Calling the customer service number on your ID card\n\nIs there anything else about your benefits I can help clarify?`,
      confidence: 'low',
      sources: []
    };
  };

  const handleSuggestedQuestion = (question) => {
    handleSendMessage(question);
  };

  const handleFeedback = async (messageId, rating) => {
    try {
      await fetch('/api/chat/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query_id: messageId,
          rating: rating
        })
      });
      
      // Update message to show feedback was submitted
      setMessages(prev => prev.map(msg => 
        msg.id === messageId 
          ? { ...msg, feedback: rating }
          : msg
      ));
    } catch (error) {
      console.error('Error submitting feedback:', error);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  const getConfidenceColor = (confidence) => {
    switch (confidence) {
      case 'high': return 'bg-green-100 text-green-800 border-green-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatTimestamp = (timestamp) => {
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    }).format(timestamp);
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <img src={SmartSPDLogo} alt="SmartSPD" className="h-8 w-auto" />
            <div className="h-6 w-px bg-slate-300"></div>
            <div>
              <h1 className="text-lg font-semibold text-slate-900">Smart Agent</h1>
              <p className="text-sm text-slate-500">{healthPlan?.plan_name || 'Demo Health Plan'}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              Online
            </Badge>
            
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
            
            <Button variant="ghost" size="sm" onClick={onLogout}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex max-w-4xl ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'} space-x-3`}>
                {/* Avatar */}
                <div className={`flex-shrink-0 ${message.type === 'user' ? 'ml-3' : 'mr-3'}`}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    message.type === 'user' 
                      ? 'bg-blue-600 text-white' 
                      : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                  }`}>
                    {message.type === 'user' ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
                  </div>
                </div>

                {/* Message Content */}
                <div className={`flex-1 ${message.type === 'user' ? 'text-right' : 'text-left'}`}>
                  <Card className={`${
                    message.type === 'user' 
                      ? 'bg-blue-600 text-white border-blue-600' 
                      : 'bg-white border-slate-200 shadow-sm'
                  }`}>
                    <CardContent className="p-4">
                      <div className="whitespace-pre-wrap leading-relaxed">
                        {message.content}
                      </div>
                      
                      {/* Bot message metadata */}
                      {message.type === 'bot' && (
                        <div className="mt-4 space-y-3">
                          {/* Confidence and timing */}
                          <div className="flex items-center space-x-2 text-sm">
                            <Badge 
                              variant="outline" 
                              className={getConfidenceColor(message.confidence)}
                            >
                              {message.confidence === 'high' && <CheckCircle className="h-3 w-3 mr-1" />}
                              {message.confidence === 'medium' && <AlertCircle className="h-3 w-3 mr-1" />}
                              {message.confidence === 'low' && <AlertCircle className="h-3 w-3 mr-1" />}
                              {message.confidence} confidence
                            </Badge>
                            
                            {message.responseTime && (
                              <Badge variant="outline" className="text-slate-600">
                                <Clock className="h-3 w-3 mr-1" />
                                {message.responseTime}ms
                              </Badge>
                            )}
                          </div>
                          
                          {/* Sources */}
                          {message.sources && message.sources.length > 0 && (
                            <div className="space-y-2">
                              <p className="text-sm font-medium text-slate-700">Sources:</p>
                              <div className="space-y-1">
                                {message.sources.map((source, index) => (
                                  <div key={index} className="flex items-center space-x-2 text-xs text-slate-600">
                                    {source.type === 'document' ? (
                                      <FileText className="h-3 w-3" />
                                    ) : (
                                      <Database className="h-3 w-3" />
                                    )}
                                    <span>
                                      {source.type === 'document' 
                                        ? `Page ${source.page_number}${source.section_title ? ` - ${source.section_title}` : ''}`
                                        : `${source.benefit_name || 'Benefit Data'}`
                                      }
                                    </span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {/* Actions */}
                          <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyToClipboard(message.content)}
                                className="h-8 px-2 text-slate-500 hover:text-slate-700"
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                            
                            {/* Feedback */}
                            {!message.feedback && (
                              <div className="flex items-center space-x-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleFeedback(message.id, 5)}
                                  className="h-8 px-2 text-slate-500 hover:text-green-600"
                                >
                                  <ThumbsUp className="h-3 w-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleFeedback(message.id, 1)}
                                  className="h-8 px-2 text-slate-500 hover:text-red-600"
                                >
                                  <ThumbsDown className="h-3 w-3" />
                                </Button>
                              </div>
                            )}
                            
                            {message.feedback && (
                              <Badge variant="outline" className="text-xs">
                                Feedback submitted
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}
                      
                      {/* Timestamp */}
                      <div className={`mt-2 text-xs ${
                        message.type === 'user' ? 'text-blue-200' : 'text-slate-500'
                      }`}>
                        {formatTimestamp(message.timestamp)}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Loading indicator */}
        {isLoading && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-start"
          >
            <div className="flex space-x-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                <Bot className="h-5 w-5 text-white" />
              </div>
              <Card className="bg-white border-slate-200 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <RefreshCw className="h-4 w-4 animate-spin text-slate-500" />
                    <span className="text-slate-600">Thinking...</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Questions */}
      {messages.length === 1 && (
        <div className="px-6 py-4 border-t border-slate-200 bg-white">
          <div className="mb-3">
            <h3 className="text-sm font-medium text-slate-700 mb-2">Suggested questions:</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {suggestedQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handleSuggestedQuestion(question)}
                  className="justify-start text-left h-auto py-2 px-3 text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                  disabled={isLoading}
                >
                  <MessageSquare className="h-3 w-3 mr-2 flex-shrink-0" />
                  <span className="truncate">{question}</span>
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="px-6 py-4 bg-white border-t border-slate-200">
        <div className="flex space-x-3">
          <div className="flex-1">
            <div className="relative">
              <Textarea
                ref={inputRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Ask me anything about your health plan benefits..."
                className="resize-none min-h-[44px] max-h-32 pr-12 border-slate-300 focus:border-blue-500 focus:ring-blue-500"
                disabled={isLoading}
                rows={1}
              />
              <Button
                onClick={() => handleSendMessage()}
                disabled={!inputValue.trim() || isLoading}
                size="sm"
                className="absolute right-2 top-2 h-8 w-8 p-0 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        
        <div className="mt-2 text-xs text-slate-500 text-center">
          SmartSPD v2 • Powered by advanced AI • Press Enter to send
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;


import { useState } from 'react';
import LandingPage from './components/LandingPage';
import ChatInterface from './components/ChatInterface';
import AuthModal from './components/AuthModal';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [healthPlan, setHealthPlan] = useState(null);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleLogin = (userData, healthPlanData) => {
    setUser(userData);
    setHealthPlan(healthPlanData);
    setShowAuthModal(false);
  };

  const handleLogout = () => {
    setUser(null);
    setHealthPlan(null);
  };

  const handleGetStarted = () => {
    setShowAuthModal(true);
  };

  // If user is logged in, show chat interface
  if (user && healthPlan) {
    return (
      <ChatInterface 
        user={user} 
        healthPlan={healthPlan} 
        onLogout={handleLogout} 
      />
    );
  }

  // Otherwise show landing page
  return (
    <>
      <LandingPage onGetStarted={handleGetStarted} />
      <AuthModal 
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onLogin={handleLogin}
      />
    </>
  );
}

export default App;

"""
SmartSPD v2 - Authentication and Authorization Service
Provides user authentication, session management, and role-based access control.
"""

import jwt
import bcrypt
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from models.database import get_db_session
import os
import secrets

class AuthService:
    def __init__(self, db=None):
        self.db = db or get_db_session()
        self.jwt_secret = os.getenv('JWT_SECRET_KEY', 'your-secret-key-change-in-production')
        self.jwt_algorithm = 'HS256'
        self.token_expiry_hours = 24
        
    def hash_password(self, password: str) -> str:
        """Hash a password using bcrypt."""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """Verify a password against its hash."""
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
    
    def generate_jwt_token(self, user_id: str, email: str, role: str) -> str:
        """Generate a JWT token for the user."""
        payload = {
            'user_id': user_id,
            'email': email,
            'role': role,
            'exp': datetime.utcnow() + timedelta(hours=self.token_expiry_hours),
            'iat': datetime.utcnow()
        }
        return jwt.encode(payload, self.jwt_secret, algorithm=self.jwt_algorithm)
    
    def verify_jwt_token(self, token: str) -> Optional[Dict]:
        """Verify and decode a JWT token."""
        try:
            payload = jwt.decode(token, self.jwt_secret, algorithms=[self.jwt_algorithm])
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
    
    def register_user(self, email: str, password: str, name: str, 
                     organization: str, role: str = 'member') -> Tuple[bool, str, Optional[Dict]]:
        """Register a new user."""
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            # Check if user already exists
            cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
            if cursor.fetchone():
                conn.close()
                return False, "User with this email already exists", None
            
            # Create new user
            user_id = str(uuid.uuid4())
            cursor.execute('''
                INSERT INTO users (id, email, password_hash, name, organization, role, is_active, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                user_id,
                email,
                self.hash_password(password),
                name,
                organization,
                role,
                1,
                datetime.utcnow().isoformat()
            ))
            
            conn.commit()
            
            # Get the created user
            cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
            user_row = cursor.fetchone()
            conn.close()
            
            user = dict(user_row) if user_row else None
            return True, "User registered successfully", user
            
        except Exception as e:
            return False, f"Registration failed: {str(e)}", None
    
    def authenticate_user(self, email: str, password: str) -> Tuple[bool, str, Optional[Dict]]:
        """Authenticate a user with email and password."""
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
            user_row = cursor.fetchone()
            
            if not user_row:
                conn.close()
                return False, "Invalid email or password", None
            
            user = dict(user_row)
            
            if not user['is_active']:
                conn.close()
                return False, "Account is deactivated", None
            
            if not self.verify_password(password, user['password_hash']):
                conn.close()
                return False, "Invalid email or password", None
            
            # Update last login
            cursor.execute(
                "UPDATE users SET last_login_at = ? WHERE id = ?",
                (datetime.utcnow().isoformat(), user['id'])
            )
            conn.commit()
            conn.close()
            
            return True, "Authentication successful", user
            
        except Exception as e:
            return False, f"Authentication failed: {str(e)}", None
    
    def create_session(self, user: Dict, ip_address: str = None, 
                      user_agent: str = None) -> Dict:
        """Create a new user session."""
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            session_id = str(uuid.uuid4())
            session_token = secrets.token_urlsafe(32)
            expires_at = datetime.utcnow() + timedelta(hours=self.token_expiry_hours)
            
            cursor.execute('''
                INSERT INTO user_sessions 
                (id, user_id, session_token, ip_address, user_agent, created_at, expires_at, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                session_id,
                user['id'],
                session_token,
                ip_address,
                user_agent,
                datetime.utcnow().isoformat(),
                expires_at.isoformat(),
                1
            ))
            
            conn.commit()
            conn.close()
            
            return {
                'id': session_id,
                'session_token': session_token,
                'expires_at': expires_at.isoformat()
            }
            
        except Exception as e:
            print(f"Error creating session: {e}")
            return None
    
    def get_user_health_plans(self, user_id: str) -> List[Dict]:
        """Get all health plans accessible to a user."""
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            # For demo purposes, return all active health plans
            cursor.execute("SELECT * FROM health_plans WHERE is_active = 1")
            plans = [dict(row) for row in cursor.fetchall()]
            conn.close()
            
            return plans
            
        except Exception as e:
            print(f"Error getting user health plans: {e}")
            return []
    
    def check_permission(self, user: Dict, health_plan_id: str, 
                        permission: str) -> bool:
        """Check if user has specific permission for a health plan."""
        # Role-based permissions
        role_permissions = {
            'admin': ['read', 'write', 'delete', 'manage_users'],
            'agent': ['read', 'write'],
            'member': ['read'],
            'hr': ['read', 'write'],
            'broker': ['read']
        }
        
        user_permissions = role_permissions.get(user.get('role'), ['read'])
        return permission in user_permissions
    
    def invalidate_session(self, session_token: str) -> bool:
        """Invalidate a user session."""
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE user_sessions 
                SET is_active = 0, ended_at = ?
                WHERE session_token = ?
            ''', (datetime.utcnow().isoformat(), session_token))
            
            conn.commit()
            success = cursor.rowcount > 0
            conn.close()
            
            return success
            
        except Exception as e:
            print(f"Error invalidating session: {e}")
            return False
    
    def get_active_session(self, session_token: str) -> Optional[Dict]:
        """Get an active session by token."""
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT s.*, u.* FROM user_sessions s
                JOIN users u ON s.user_id = u.id
                WHERE s.session_token = ? AND s.is_active = 1 
                AND datetime(s.expires_at) > datetime('now')
            ''', (session_token,))
            
            row = cursor.fetchone()
            conn.close()
            
            if row:
                session_data = dict(row)
                return {
                    'session': {
                        'id': session_data['id'],
                        'session_token': session_data['session_token'],
                        'expires_at': session_data['expires_at']
                    },
                    'user': {
                        'id': session_data['user_id'],
                        'email': session_data['email'],
                        'name': session_data['name'],
                        'role': session_data['role'],
                        'organization': session_data['organization']
                    }
                }
            
            return None
            
        except Exception as e:
            print(f"Error getting active session: {e}")
            return None
    
    def refresh_session(self, session_token: str) -> Optional[Dict]:
        """Refresh an active session."""
        try:
            conn = self.db.get_connection()
            cursor = conn.cursor()
            
            new_expires_at = datetime.utcnow() + timedelta(hours=self.token_expiry_hours)
            
            cursor.execute('''
                UPDATE user_sessions 
                SET expires_at = ?
                WHERE session_token = ? AND is_active = 1
            ''', (new_expires_at.isoformat(), session_token))
            
            if cursor.rowcount > 0:
                conn.commit()
                conn.close()
                return {'expires_at': new_expires_at.isoformat()}
            
            conn.close()
            return None
            
        except Exception as e:
            print(f"Error refreshing session: {e}")
            return None


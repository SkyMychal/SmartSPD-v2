"""
SmartSPD v2 - Caching Service
Provides in-memory and persistent caching for query results, embeddings, and frequently accessed data.
"""

import json
import hashlib
import time
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import pickle
import os

class CacheService:
    def __init__(self, cache_dir: str = None, max_memory_items: int = 1000):
        self.cache_dir = cache_dir or os.path.join(os.path.dirname(__file__), '..', 'cache')
        self.max_memory_items = max_memory_items
        
        # In-memory cache for fast access
        self.memory_cache = {}
        self.cache_timestamps = {}
        self.cache_access_count = {}
        
        # Ensure cache directory exists
        os.makedirs(self.cache_dir, exist_ok=True)
        
        # Cache statistics
        self.stats = {
            'hits': 0,
            'misses': 0,
            'memory_hits': 0,
            'disk_hits': 0,
            'evictions': 0
        }
    
    def _generate_cache_key(self, key_data: Any) -> str:
        """Generate a consistent cache key from data."""
        if isinstance(key_data, str):
            return hashlib.md5(key_data.encode()).hexdigest()
        elif isinstance(key_data, dict):
            # Sort dict keys for consistent hashing
            sorted_data = json.dumps(key_data, sort_keys=True)
            return hashlib.md5(sorted_data.encode()).hexdigest()
        else:
            # Convert to string and hash
            return hashlib.md5(str(key_data).encode()).hexdigest()
    
    def _get_file_path(self, cache_key: str) -> str:
        """Get file path for cache key."""
        return os.path.join(self.cache_dir, f"{cache_key}.cache")
    
    def _cleanup_memory_cache(self):
        """Remove least recently used items from memory cache."""
        if len(self.memory_cache) <= self.max_memory_items:
            return
        
        # Sort by access count and timestamp (LRU)
        items = list(self.memory_cache.keys())
        items.sort(key=lambda k: (
            self.cache_access_count.get(k, 0),
            self.cache_timestamps.get(k, 0)
        ))
        
        # Remove oldest items
        items_to_remove = len(self.memory_cache) - self.max_memory_items + 100  # Remove extra for buffer
        for i in range(min(items_to_remove, len(items))):
            key = items[i]
            del self.memory_cache[key]
            del self.cache_timestamps[key]
            del self.cache_access_count[key]
            self.stats['evictions'] += 1
    
    def set(self, key_data: Any, value: Any, ttl_seconds: int = 3600, 
            persist_to_disk: bool = True) -> str:
        """Store value in cache with optional TTL."""
        cache_key = self._generate_cache_key(key_data)
        current_time = time.time()
        
        cache_item = {
            'value': value,
            'timestamp': current_time,
            'ttl': ttl_seconds,
            'expires_at': current_time + ttl_seconds if ttl_seconds > 0 else None
        }
        
        # Store in memory cache
        self.memory_cache[cache_key] = cache_item
        self.cache_timestamps[cache_key] = current_time
        self.cache_access_count[cache_key] = 0
        
        # Cleanup if needed
        self._cleanup_memory_cache()
        
        # Persist to disk if requested
        if persist_to_disk:
            try:
                file_path = self._get_file_path(cache_key)
                with open(file_path, 'wb') as f:
                    pickle.dump(cache_item, f)
            except Exception as e:
                print(f"Error persisting cache to disk: {e}")
        
        return cache_key
    
    def get(self, key_data: Any) -> Optional[Any]:
        """Retrieve value from cache."""
        cache_key = self._generate_cache_key(key_data)
        current_time = time.time()
        
        # Check memory cache first
        if cache_key in self.memory_cache:
            cache_item = self.memory_cache[cache_key]
            
            # Check if expired
            if cache_item.get('expires_at') and current_time > cache_item['expires_at']:
                del self.memory_cache[cache_key]
                del self.cache_timestamps[cache_key]
                del self.cache_access_count[cache_key]
                self.stats['misses'] += 1
                return None
            
            # Update access statistics
            self.cache_access_count[cache_key] += 1
            self.cache_timestamps[cache_key] = current_time
            self.stats['hits'] += 1
            self.stats['memory_hits'] += 1
            
            return cache_item['value']
        
        # Check disk cache
        file_path = self._get_file_path(cache_key)
        if os.path.exists(file_path):
            try:
                with open(file_path, 'rb') as f:
                    cache_item = pickle.load(f)
                
                # Check if expired
                if cache_item.get('expires_at') and current_time > cache_item['expires_at']:
                    os.remove(file_path)
                    self.stats['misses'] += 1
                    return None
                
                # Load back into memory cache
                self.memory_cache[cache_key] = cache_item
                self.cache_timestamps[cache_key] = current_time
                self.cache_access_count[cache_key] = 1
                
                self.stats['hits'] += 1
                self.stats['disk_hits'] += 1
                
                return cache_item['value']
                
            except Exception as e:
                print(f"Error loading cache from disk: {e}")
                # Remove corrupted file
                try:
                    os.remove(file_path)
                except:
                    pass
        
        self.stats['misses'] += 1
        return None
    
    def delete(self, key_data: Any) -> bool:
        """Delete value from cache."""
        cache_key = self._generate_cache_key(key_data)
        
        # Remove from memory
        removed = False
        if cache_key in self.memory_cache:
            del self.memory_cache[cache_key]
            del self.cache_timestamps[cache_key]
            del self.cache_access_count[cache_key]
            removed = True
        
        # Remove from disk
        file_path = self._get_file_path(cache_key)
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                removed = True
            except Exception as e:
                print(f"Error removing cache file: {e}")
        
        return removed
    
    def clear(self, pattern: str = None) -> int:
        """Clear cache items, optionally matching a pattern."""
        removed_count = 0
        
        if pattern is None:
            # Clear all
            removed_count = len(self.memory_cache)
            self.memory_cache.clear()
            self.cache_timestamps.clear()
            self.cache_access_count.clear()
            
            # Clear disk cache
            try:
                for filename in os.listdir(self.cache_dir):
                    if filename.endswith('.cache'):
                        os.remove(os.path.join(self.cache_dir, filename))
                        removed_count += 1
            except Exception as e:
                print(f"Error clearing disk cache: {e}")
        else:
            # Clear items matching pattern (simple substring match)
            keys_to_remove = []
            for key in self.memory_cache.keys():
                if pattern in key:
                    keys_to_remove.append(key)
            
            for key in keys_to_remove:
                del self.memory_cache[key]
                del self.cache_timestamps[key]
                del self.cache_access_count[key]
                removed_count += 1
                
                # Remove from disk
                file_path = self._get_file_path(key)
                if os.path.exists(file_path):
                    try:
                        os.remove(file_path)
                    except:
                        pass
        
        return removed_count
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total_requests = self.stats['hits'] + self.stats['misses']
        hit_rate = (self.stats['hits'] / total_requests * 100) if total_requests > 0 else 0
        
        return {
            **self.stats,
            'total_requests': total_requests,
            'hit_rate_percent': round(hit_rate, 2),
            'memory_cache_size': len(self.memory_cache),
            'disk_cache_files': len([f for f in os.listdir(self.cache_dir) if f.endswith('.cache')])
        }
    
    def cache_query_result(self, query: str, health_plan_id: str, 
                          result: Dict[str, Any], ttl_seconds: int = 1800) -> str:
        """Cache a query result with specific key format."""
        cache_key_data = {
            'type': 'query_result',
            'query': query.lower().strip(),
            'health_plan_id': health_plan_id,
            'timestamp': datetime.now().strftime('%Y-%m-%d')  # Cache per day
        }
        return self.set(cache_key_data, result, ttl_seconds)
    
    def get_cached_query_result(self, query: str, health_plan_id: str) -> Optional[Dict[str, Any]]:
        """Get cached query result."""
        cache_key_data = {
            'type': 'query_result',
            'query': query.lower().strip(),
            'health_plan_id': health_plan_id,
            'timestamp': datetime.now().strftime('%Y-%m-%d')
        }
        return self.get(cache_key_data)
    
    def cache_embeddings(self, text: str, embeddings: List[float], 
                        model_name: str = 'default', ttl_seconds: int = 86400) -> str:
        """Cache text embeddings."""
        cache_key_data = {
            'type': 'embeddings',
            'text_hash': hashlib.md5(text.encode()).hexdigest(),
            'model': model_name
        }
        return self.set(cache_key_data, embeddings, ttl_seconds)
    
    def get_cached_embeddings(self, text: str, model_name: str = 'default') -> Optional[List[float]]:
        """Get cached embeddings."""
        cache_key_data = {
            'type': 'embeddings',
            'text_hash': hashlib.md5(text.encode()).hexdigest(),
            'model': model_name
        }
        return self.get(cache_key_data)

# Global cache instance
cache_service = CacheService()


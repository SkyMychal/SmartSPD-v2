"""
SmartSPD v2 - Advanced Document Processing Service
=================================================

This module provides comprehensive document processing capabilities for PDF and Excel files,
including intelligent chunking, table extraction, and knowledge graph population.
"""

import os
import json
import hashlib
import logging
import re
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import uuid

import fitz  # PyMuPDF
import pdfplumber
import openpyxl
import pandas as pd
from openai import OpenAI

from src.models.smartspd_models import (
    SPDDocument, BPSData, DocumentChunk, HealthPlan, 
    DocumentStatus, db
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DocumentProcessor:
    """Advanced document processor for SPD and BPS files."""
    
    def __init__(self, openai_api_key: str = None):
        """Initialize the document processor."""
        self.openai_client = None
        if openai_api_key:
            try:
                self.openai_client = OpenAI(api_key=openai_api_key)
            except Exception as e:
                logger.warning(f"Failed to initialize OpenAI client: {e}")
        
        self.chunk_size = 1000
        self.chunk_overlap = 200
        self.max_chunk_size = 2000
        
    def calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA-256 hash of a file."""
        hash_sha256 = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_sha256.update(chunk)
            return hash_sha256.hexdigest()
        except Exception as e:
            logger.error(f"Error calculating file hash: {e}")
            return ""
    
    def process_spd_document(self, file_path: str, health_plan_id: str, 
                           uploaded_by: str = None) -> SPDDocument:
        """Process an SPD PDF document."""
        try:
            # Calculate file metadata
            file_size = os.path.getsize(file_path)
            file_hash = self.calculate_file_hash(file_path)
            file_name = os.path.basename(file_path)
            
            # Create SPD document record
            spd_doc = SPDDocument(
                health_plan_id=health_plan_id,
                file_name=file_name,
                file_path=file_path,
                file_size=file_size,
                file_hash=file_hash,
                mime_type="application/pdf",
                processing_status=DocumentStatus.PROCESSING.value,
                uploaded_by=uploaded_by
            )
            
            db.session.add(spd_doc)
            db.session.commit()
            
            # Process the PDF
            self._process_pdf_content(spd_doc)
            
            # Update processing status
            spd_doc.processing_status = DocumentStatus.PROCESSED.value
            spd_doc.processed_date = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"Successfully processed SPD document: {file_name}")
            return spd_doc
            
        except Exception as e:
            logger.error(f"Error processing SPD document: {e}")
            if 'spd_doc' in locals():
                spd_doc.processing_status = DocumentStatus.FAILED.value
                spd_doc.processing_error = str(e)
                db.session.commit()
            raise
    
    def _process_pdf_content(self, spd_doc: SPDDocument):
        """Process PDF content and create chunks."""
        try:
            # Extract text and structure using multiple methods
            pdf_data = self._extract_pdf_data(spd_doc.file_path)
            
            # Update document metadata
            spd_doc.page_count = pdf_data.get('page_count', 0)
            spd_doc.doc_metadata = pdf_data.get('metadata', {})
            
            # Create intelligent chunks
            chunks = self._create_intelligent_chunks(pdf_data)
            
            # Generate embeddings for chunks
            if self.openai_client:
                chunks_with_embeddings = self._generate_embeddings(chunks)
            else:
                chunks_with_embeddings = chunks
            
            # Save chunks to database
            self._save_chunks_to_db(spd_doc, chunks_with_embeddings)
            
            # Update chunk count
            spd_doc.chunk_count = len(chunks_with_embeddings)
            
        except Exception as e:
            logger.error(f"Error processing PDF content: {e}")
            raise
    
    def _extract_pdf_data(self, file_path: str) -> Dict[str, Any]:
        """Extract comprehensive data from PDF using multiple libraries."""
        pdf_data = {
            'pages': [],
            'tables': [],
            'headings': [],
            'text_blocks': [],
            'metadata': {},
            'page_count': 0
        }
        
        try:
            # Use pdfplumber for detailed text extraction
            with pdfplumber.open(file_path) as pdf:
                pdf_data['page_count'] = len(pdf.pages)
                
                for page_num, page in enumerate(pdf.pages, 1):
                    page_data = self._extract_page_data(page, page_num)
                    pdf_data['pages'].append(page_data)
                    
                    # Extract tables from this page
                    page_tables = self._extract_page_tables(page, page_num)
                    pdf_data['tables'].extend(page_tables)
            
            # Use PyMuPDF for additional metadata
            with fitz.open(file_path) as doc:
                pdf_data['metadata'] = {
                    'title': doc.metadata.get('title', ''),
                    'author': doc.metadata.get('author', ''),
                    'subject': doc.metadata.get('subject', ''),
                    'creator': doc.metadata.get('creator', ''),
                    'producer': doc.metadata.get('producer', ''),
                    'creation_date': doc.metadata.get('creationDate', ''),
                    'modification_date': doc.metadata.get('modDate', ''),
                    'toc': doc.get_toc()
                }
            
        except Exception as e:
            logger.error(f"Error extracting PDF data: {e}")
            raise
        
        return pdf_data
    
    def _extract_page_data(self, page, page_num: int) -> Dict[str, Any]:
        """Extract data from a single PDF page."""
        page_data = {
            'page_number': page_num,
            'text': '',
            'words': [],
            'lines': [],
            'rects': [],
            'tables': [],
            'headings': []
        }
        
        try:
            # Extract text
            page_data['text'] = page.extract_text() or ''
            
            # Extract words with positioning
            page_data['words'] = page.extract_words()
            
            # Extract lines and rectangles
            page_data['lines'] = page.lines
            page_data['rects'] = page.rects
            
            # Identify headings based on font characteristics
            page_data['headings'] = self._identify_headings(page)
            
        except Exception as e:
            logger.warning(f"Error extracting page {page_num} data: {e}")
        
        return page_data
    
    def _extract_page_tables(self, page, page_num: int) -> List[Dict[str, Any]]:
        """Extract tables from a PDF page."""
        tables = []
        
        try:
            # Extract tables using pdfplumber
            page_tables = page.extract_tables()
            
            for i, table_data in enumerate(page_tables):
                if table_data and len(table_data) > 1:  # Must have header + data
                    table = {
                        'page_number': page_num,
                        'table_index': i,
                        'raw_data': table_data,
                        'structured_data': self._structure_table_data(table_data),
                        'text_representation': self._table_to_text(table_data)
                    }
                    tables.append(table)
                    
        except Exception as e:
            logger.warning(f"Error extracting tables from page {page_num}: {e}")
        
        return tables
    
    def _identify_headings(self, page) -> List[Dict[str, Any]]:
        """Identify headings based on text characteristics."""
        headings = []
        
        try:
            # Get characters with font information
            chars = page.chars
            if not chars:
                return headings
            
            # Analyze font sizes
            font_sizes = [char.get('size', 0) for char in chars if char.get('size')]
            if not font_sizes:
                return headings
            
            avg_font_size = sum(font_sizes) / len(font_sizes)
            large_font_threshold = avg_font_size * 1.2
            
            # Group characters by line
            lines = {}
            for char in chars:
                line_key = round(char.get('top', 0), 1)
                if line_key not in lines:
                    lines[line_key] = []
                lines[line_key].append(char)
            
            # Analyze each line for heading characteristics
            for line_y, line_chars in lines.items():
                if not line_chars:
                    continue
                
                line_font_sizes = [char.get('size', 0) for char in line_chars if char.get('size')]
                if not line_font_sizes:
                    continue
                
                avg_line_font_size = sum(line_font_sizes) / len(line_font_sizes)
                
                # Check for bold text
                bold_chars = [char for char in line_chars if 'bold' in char.get('fontname', '').lower()]
                bold_ratio = len(bold_chars) / len(line_chars) if line_chars else 0
                
                # Determine if this is likely a heading
                is_heading = (
                    avg_line_font_size > large_font_threshold or
                    bold_ratio > 0.5 or
                    any('ARTICLE' in char.get('text', '').upper() for char in line_chars)
                )
                
                if is_heading:
                    line_text = ''.join(char.get('text', '') for char in line_chars).strip()
                    if line_text and len(line_text) > 2:
                        headings.append({
                            'text': line_text,
                            'level': self._determine_heading_level(line_text, avg_line_font_size, bold_ratio),
                            'font_size': avg_line_font_size,
                            'bold_ratio': bold_ratio,
                            'y_position': line_y
                        })
                        
        except Exception as e:
            logger.warning(f"Error identifying headings: {e}")
        
        return headings
    
    def _determine_heading_level(self, text: str, font_size: float, bold_ratio: float) -> int:
        """Determine the hierarchical level of a heading."""
        text_upper = text.upper()
        
        # Level 1: Articles
        if 'ARTICLE' in text_upper and any(roman in text_upper for roman in ['I', 'II', 'III', 'IV', 'V']):
            return 1
        
        # Level 2: Major sections with numbers
        if re.match(r'^\d+\.\d+\s*', text) or re.match(r'^\d+\.\s', text):
            return 2
        
        # Level 3: Subsections
        if font_size > 12 and bold_ratio > 0.3:
            return 3
        
        return 4
    
    def _structure_table_data(self, table_data: List[List]) -> List[Dict[str, Any]]:
        """Convert raw table data to structured format."""
        if not table_data or len(table_data) < 2:
            return []
        
        headers = [str(h).strip() if h else f"Column_{i}" for i, h in enumerate(table_data[0])]
        rows = table_data[1:]
        
        structured_data = []
        for row in rows:
            if len(row) >= len(headers):
                row_dict = {}
                for i, header in enumerate(headers):
                    if i < len(row):
                        row_dict[header] = str(row[i]).strip() if row[i] else ""
                structured_data.append(row_dict)
        
        return structured_data
    
    def _table_to_text(self, table_data: List[List]) -> str:
        """Convert table data to searchable text format."""
        if not table_data:
            return ""
        
        text_parts = []
        for row in table_data:
            row_text = " | ".join(str(cell).strip() if cell else "" for cell in row)
            if row_text.strip():
                text_parts.append(row_text)
        
        return "\n".join(text_parts)
    
    def _create_intelligent_chunks(self, pdf_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Create intelligent chunks preserving context and structure."""
        chunks = []
        
        try:
            # Process each page
            for page_data in pdf_data['pages']:
                page_chunks = self._chunk_page_content(page_data, pdf_data.get('tables', []))
                chunks.extend(page_chunks)
            
            # Add table chunks
            table_chunks = self._create_table_chunks(pdf_data.get('tables', []))
            chunks.extend(table_chunks)
            
            # Post-process chunks for optimization
            optimized_chunks = self._optimize_chunks(chunks)
            
        except Exception as e:
            logger.error(f"Error creating intelligent chunks: {e}")
            raise
        
        return optimized_chunks
    
    def _chunk_page_content(self, page_data: Dict[str, Any], all_tables: List[Dict]) -> List[Dict[str, Any]]:
        """Chunk content from a single page."""
        chunks = []
        page_text = page_data.get('text', '')
        page_num = page_data.get('page_number', 0)
        
        if not page_text.strip():
            return chunks
        
        # Split text into paragraphs
        paragraphs = [p.strip() for p in page_text.split('\n\n') if p.strip()]
        
        current_chunk = ""
        current_section = ""
        
        # Identify current section from headings
        headings = page_data.get('headings', [])
        if headings:
            current_section = headings[0].get('text', '')
        
        for paragraph in paragraphs:
            # Check if this paragraph would make the chunk too large
            if len(current_chunk) + len(paragraph) > self.chunk_size and current_chunk:
                # Save current chunk
                chunk = self._create_chunk_dict(
                    content=current_chunk,
                    page_number=page_num,
                    section_title=current_section,
                    content_type="text"
                )
                chunks.append(chunk)
                
                # Start new chunk with overlap
                overlap_text = self._get_overlap_text(current_chunk)
                current_chunk = overlap_text + paragraph
            else:
                current_chunk += "\n\n" + paragraph if current_chunk else paragraph
            
            # Update section if we encounter a heading
            if self._is_heading_paragraph(paragraph):
                current_section = paragraph.strip()
        
        # Add final chunk if there's content
        if current_chunk.strip():
            chunk = self._create_chunk_dict(
                content=current_chunk,
                page_number=page_num,
                section_title=current_section,
                content_type="text"
            )
            chunks.append(chunk)
        
        return chunks
    
    def _create_table_chunks(self, tables: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Create chunks specifically for table content."""
        chunks = []
        
        for table in tables:
            # Create a chunk for the table
            table_text = table.get('text_representation', '')
            if table_text.strip():
                chunk = self._create_chunk_dict(
                    content=table_text,
                    page_number=table.get('page_number', 0),
                    section_title=f"Table {table.get('table_index', 0) + 1}",
                    content_type="table",
                    metadata={
                        'table_index': table.get('table_index', 0),
                        'structured_data': table.get('structured_data', [])
                    }
                )
                chunks.append(chunk)
        
        return chunks
    
    def _create_chunk_dict(self, content: str, page_number: int, section_title: str,
                          content_type: str, metadata: Dict = None) -> Dict[str, Any]:
        """Create a standardized chunk dictionary."""
        return {
            'content': content.strip(),
            'page_number': page_number,
            'section_title': section_title,
            'content_type': content_type,
            'word_count': len(content.split()),
            'char_count': len(content),
            'metadata': metadata or {}
        }
    
    def _get_overlap_text(self, text: str) -> str:
        """Get overlap text for chunk continuity."""
        words = text.split()
        if len(words) <= self.chunk_overlap:
            return text
        
        overlap_words = words[-self.chunk_overlap:]
        return " ".join(overlap_words)
    
    def _is_heading_paragraph(self, paragraph: str) -> bool:
        """Check if a paragraph is likely a heading."""
        paragraph = paragraph.strip()
        
        # Check for common heading patterns
        heading_patterns = [
            r'^ARTICLE\s+[IVX]+',
            r'^\d+\.\d+\s+',
            r'^\d+\.\s+[A-Z]',
            r'^[A-Z\s]{10,}$'  # All caps text
        ]
        
        for pattern in heading_patterns:
            if re.match(pattern, paragraph):
                return True
        
        return False
    
    def _optimize_chunks(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Optimize chunks for better retrieval and processing."""
        optimized = []
        
        for i, chunk in enumerate(chunks):
            # Add chunk index
            chunk['chunk_index'] = i
            
            # Ensure minimum chunk size (merge small chunks)
            if len(chunk['content']) < 100 and i > 0 and optimized:
                # Merge with previous chunk if it's small
                prev_chunk = optimized[-1]
                if len(prev_chunk['content']) + len(chunk['content']) < self.max_chunk_size:
                    prev_chunk['content'] += "\n\n" + chunk['content']
                    prev_chunk['word_count'] += chunk['word_count']
                    prev_chunk['char_count'] += chunk['char_count']
                    continue
            
            optimized.append(chunk)
        
        return optimized
    
    def _generate_embeddings(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate embeddings for chunks using OpenAI."""
        if not self.openai_client:
            logger.warning("OpenAI client not available, skipping embeddings")
            return chunks
        
        try:
            # Extract text content for embedding
            texts = [chunk['content'] for chunk in chunks]
            
            # Generate embeddings in batches
            batch_size = 100
            all_embeddings = []
            
            for i in range(0, len(texts), batch_size):
                batch_texts = texts[i:i + batch_size]
                
                response = self.openai_client.embeddings.create(
                    input=batch_texts,
                    model="text-embedding-3-small"
                )
                
                batch_embeddings = [embedding.embedding for embedding in response.data]
                all_embeddings.extend(batch_embeddings)
            
            # Add embeddings to chunks
            for chunk, embedding in zip(chunks, all_embeddings):
                chunk['embedding_vector'] = embedding
            
            logger.info(f"Generated embeddings for {len(chunks)} chunks")
            
        except Exception as e:
            logger.error(f"Error generating embeddings: {e}")
        
        return chunks
    
    def _save_chunks_to_db(self, spd_doc: SPDDocument, chunks: List[Dict[str, Any]]):
        """Save chunks to the database."""
        try:
            for chunk_data in chunks:
                chunk = DocumentChunk(
                    spd_document_id=spd_doc.id,
                    chunk_index=chunk_data['chunk_index'],
                    content=chunk_data['content'],
                    content_type=chunk_data['content_type'],
                    page_number=chunk_data['page_number'],
                    section_title=chunk_data['section_title'],
                    word_count=chunk_data['word_count'],
                    char_count=chunk_data['char_count'],
                    embedding_vector=chunk_data.get('embedding_vector'),
                    chunk_metadata=chunk_data['metadata']
                )
                db.session.add(chunk)
            
            db.session.commit()
            logger.info(f"Saved {len(chunks)} chunks to database")
            
        except Exception as e:
            logger.error(f"Error saving chunks to database: {e}")
            db.session.rollback()
            raise
    
    def process_bps_document(self, file_path: str, health_plan_id: str,
                           uploaded_by: str = None) -> BPSData:
        """Process a BPS Excel document."""
        try:
            # Calculate file metadata
            file_size = os.path.getsize(file_path)
            file_hash = self.calculate_file_hash(file_path)
            file_name = os.path.basename(file_path)
            
            # Create BPS data record
            bps_data = BPSData(
                health_plan_id=health_plan_id,
                file_name=file_name,
                file_path=file_path,
                file_hash=file_hash,
                processing_status=DocumentStatus.PROCESSING.value,
                uploaded_by=uploaded_by
            )
            
            db.session.add(bps_data)
            db.session.commit()
            
            # Process the Excel file
            self._process_excel_content(bps_data)
            
            # Update processing status
            bps_data.processing_status = DocumentStatus.PROCESSED.value
            bps_data.processed_date = datetime.utcnow()
            db.session.commit()
            
            logger.info(f"Successfully processed BPS document: {file_name}")
            return bps_data
            
        except Exception as e:
            logger.error(f"Error processing BPS document: {e}")
            if 'bps_data' in locals():
                bps_data.processing_status = DocumentStatus.FAILED.value
                bps_data.processing_error = str(e)
                db.session.commit()
            raise
    
    def _process_excel_content(self, bps_data: BPSData):
        """Process Excel content and extract structured data."""
        try:
            # Load workbook
            workbook = openpyxl.load_workbook(bps_data.file_path, data_only=True)
            
            structured_data = {
                'worksheets': [],
                'benefits_summary': {},
                'metadata': {
                    'worksheet_names': workbook.sheetnames,
                    'processed_date': datetime.utcnow().isoformat()
                }
            }
            
            # Process each worksheet
            for sheet_name in workbook.sheetnames:
                worksheet_data = self._process_worksheet(workbook[sheet_name], sheet_name)
                structured_data['worksheets'].append(worksheet_data)
            
            # Generate benefits summary
            benefits_summary = self._generate_benefits_summary(structured_data['worksheets'])
            structured_data['benefits_summary'] = benefits_summary
            
            # Update BPS data
            bps_data.worksheet_count = len(workbook.sheetnames)
            bps_data.structured_data = structured_data
            bps_data.benefits_summary = benefits_summary
            
        except Exception as e:
            logger.error(f"Error processing Excel content: {e}")
            raise
    
    def _process_worksheet(self, worksheet, sheet_name: str) -> Dict[str, Any]:
        """Process a single Excel worksheet."""
        worksheet_data = {
            'name': sheet_name,
            'data': [],
            'headers': [],
            'metadata': {
                'max_row': worksheet.max_row,
                'max_column': worksheet.max_column
            }
        }
        
        try:
            # Convert to pandas DataFrame for easier processing
            data = []
            for row in worksheet.iter_rows(values_only=True):
                data.append(row)
            
            if data:
                # First row as headers
                headers = [str(cell) if cell is not None else f"Column_{i}" 
                          for i, cell in enumerate(data[0])]
                worksheet_data['headers'] = headers
                
                # Process data rows
                for row in data[1:]:
                    row_dict = {}
                    for i, cell in enumerate(row):
                        if i < len(headers):
                            row_dict[headers[i]] = str(cell) if cell is not None else ""
                    worksheet_data['data'].append(row_dict)
            
        except Exception as e:
            logger.warning(f"Error processing worksheet {sheet_name}: {e}")
        
        return worksheet_data
    
    def _generate_benefits_summary(self, worksheets: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a summary of benefits from worksheet data."""
        summary = {
            'benefit_categories': [],
            'coverage_tiers': [],
            'deductibles': {},
            'copays': {},
            'coinsurance': {},
            'out_of_pocket_maximums': {}
        }
        
        try:
            for worksheet in worksheets:
                sheet_name = worksheet['name'].lower()
                data = worksheet['data']
                
                # Identify benefit categories based on sheet name
                if 'medical' in sheet_name:
                    summary['benefit_categories'].append('Medical')
                elif 'dental' in sheet_name:
                    summary['benefit_categories'].append('Dental')
                elif 'vision' in sheet_name:
                    summary['benefit_categories'].append('Vision')
                elif 'prescription' in sheet_name or 'rx' in sheet_name:
                    summary['benefit_categories'].append('Prescription')
                
                # Extract key benefit information
                for row in data:
                    self._extract_benefit_info(row, summary)
            
        except Exception as e:
            logger.warning(f"Error generating benefits summary: {e}")
        
        return summary
    
    def _extract_benefit_info(self, row: Dict[str, Any], summary: Dict[str, Any]):
        """Extract benefit information from a data row."""
        try:
            # Look for deductible information
            for key, value in row.items():
                key_lower = key.lower()
                value_str = str(value).lower()
                
                if 'deductible' in key_lower and value_str.replace('$', '').replace(',', '').isdigit():
                    summary['deductibles'][key] = value
                elif 'copay' in key_lower and '$' in value_str:
                    summary['copays'][key] = value
                elif 'coinsurance' in key_lower and '%' in value_str:
                    summary['coinsurance'][key] = value
                elif 'out of pocket' in key_lower or 'oop' in key_lower:
                    summary['out_of_pocket_maximums'][key] = value
                    
        except Exception as e:
            logger.debug(f"Error extracting benefit info from row: {e}")

# Utility functions for external use

def process_uploaded_spd(file_path: str, health_plan_id: str, openai_api_key: str = None,
                        uploaded_by: str = None) -> SPDDocument:
    """Process an uploaded SPD document."""
    processor = DocumentProcessor(openai_api_key)
    return processor.process_spd_document(file_path, health_plan_id, uploaded_by)

def process_uploaded_bps(file_path: str, health_plan_id: str, uploaded_by: str = None) -> BPSData:
    """Process an uploaded BPS document."""
    processor = DocumentProcessor()
    return processor.process_bps_document(file_path, health_plan_id, uploaded_by)


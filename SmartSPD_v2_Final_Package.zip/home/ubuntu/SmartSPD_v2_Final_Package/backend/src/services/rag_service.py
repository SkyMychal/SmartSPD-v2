"""
SmartSPD v2 - Advanced RAG Service
=================================

This module provides comprehensive Retrieval-Augmented Generation (RAG) capabilities
including hybrid search, semantic similarity, and intelligent query processing.
"""

import os
import json
import logging
import re
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import uuid
import asyncio
from concurrent.futures import ThreadPoolExecutor

import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import numpy as np
from openai import OpenAI

from src.models.smartspd_models import (
    DocumentChunk, QueryRecord, HealthPlan, SPDDocument, BPSData,
    QueryStatus, ConfidenceLevel, db
)
from src.services.knowledge_graph import KnowledgeGraphService

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class HybridSearchEngine:
    """Hybrid search engine combining semantic and keyword search."""
    
    def __init__(self, embedding_model_name: str = "all-MiniLM-L6-v2"):
        """Initialize the hybrid search engine."""
        try:
            self.embedding_model = SentenceTransformer(embedding_model_name)
            logger.info(f"Loaded embedding model: {embedding_model_name}")
        except Exception as e:
            logger.error(f"Failed to load embedding model: {e}")
            self.embedding_model = None
        
        # Initialize ChromaDB
        self.chroma_client = None
        self.collection = None
        self._initialize_chromadb()
        
        # Search weights
        self.semantic_weight = 0.7
        self.keyword_weight = 0.3
        
    def _initialize_chromadb(self):
        """Initialize ChromaDB for vector storage."""
        try:
            # Use persistent storage
            persist_directory = "/tmp/smartspd_chromadb"
            os.makedirs(persist_directory, exist_ok=True)
            
            self.chroma_client = chromadb.PersistentClient(
                path=persist_directory,
                settings=Settings(
                    anonymized_telemetry=False,
                    allow_reset=True
                )
            )
            
            # Get or create collection
            self.collection = self.chroma_client.get_or_create_collection(
                name="smartspd_documents",
                metadata={"description": "SmartSPD document chunks with embeddings"}
            )
            
            logger.info("ChromaDB initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize ChromaDB: {e}")
            self.chroma_client = None
            self.collection = None
    
    def add_document_chunks(self, chunks: List[DocumentChunk]) -> bool:
        """Add document chunks to the search index."""
        if not self.collection or not self.embedding_model:
            logger.warning("Search engine not properly initialized")
            return False
        
        try:
            documents = []
            embeddings = []
            metadatas = []
            ids = []
            
            for chunk in chunks:
                # Prepare document text
                documents.append(chunk.content)
                
                # Generate or use existing embedding
                if chunk.embedding_vector:
                    embeddings.append(chunk.embedding_vector)
                else:
                    embedding = self.embedding_model.encode(chunk.content).tolist()
                    embeddings.append(embedding)
                    
                    # Update chunk with embedding
                    chunk.embedding_vector = embedding
                    db.session.commit()
                
                # Prepare metadata
                metadata = {
                    "chunk_id": chunk.id,
                    "document_id": chunk.spd_document_id,
                    "page_number": chunk.page_number or 0,
                    "section_title": chunk.section_title or "",
                    "content_type": chunk.content_type or "text",
                    "word_count": chunk.word_count or 0,
                    "char_count": chunk.char_count or 0
                }
                metadatas.append(metadata)
                ids.append(chunk.id)
            
            # Add to ChromaDB
            self.collection.add(
                documents=documents,
                embeddings=embeddings,
                metadatas=metadatas,
                ids=ids
            )
            
            logger.info(f"Added {len(chunks)} chunks to search index")
            return True
            
        except Exception as e:
            logger.error(f"Error adding chunks to search index: {e}")
            return False
    
    def semantic_search(self, query: str, health_plan_id: str, 
                       top_k: int = 10) -> List[Dict[str, Any]]:
        """Perform semantic search using embeddings."""
        if not self.collection or not self.embedding_model:
            logger.warning("Search engine not properly initialized")
            return []
        
        try:
            # Generate query embedding
            query_embedding = self.embedding_model.encode(query).tolist()
            
            # Get document IDs for this health plan
            health_plan = HealthPlan.query.get(health_plan_id)
            if not health_plan:
                logger.warning(f"Health plan not found: {health_plan_id}")
                return []
            
            document_ids = [doc.id for doc in health_plan.spd_documents]
            
            # Perform semantic search
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k * 2,  # Get more results to filter by health plan
                include=["documents", "metadatas", "distances"]
            )
            
            # Filter results by health plan and format
            filtered_results = []
            for i, metadata in enumerate(results['metadatas'][0]):
                if metadata['document_id'] in document_ids:
                    result = {
                        'chunk_id': metadata['chunk_id'],
                        'content': results['documents'][0][i],
                        'metadata': metadata,
                        'semantic_score': 1 - results['distances'][0][i],  # Convert distance to similarity
                        'search_type': 'semantic'
                    }
                    filtered_results.append(result)
                    
                    if len(filtered_results) >= top_k:
                        break
            
            return filtered_results
            
        except Exception as e:
            logger.error(f"Error in semantic search: {e}")
            return []
    
    def keyword_search(self, query: str, health_plan_id: str, 
                      top_k: int = 10) -> List[Dict[str, Any]]:
        """Perform keyword-based search."""
        try:
            # Get health plan documents
            health_plan = HealthPlan.query.get(health_plan_id)
            if not health_plan:
                return []
            
            # Extract keywords from query
            keywords = self._extract_keywords(query)
            
            # Search in document chunks
            results = []
            for spd_doc in health_plan.spd_documents:
                for chunk in spd_doc.chunks:
                    score = self._calculate_keyword_score(chunk.content, keywords)
                    if score > 0:
                        result = {
                            'chunk_id': chunk.id,
                            'content': chunk.content,
                            'metadata': {
                                'chunk_id': chunk.id,
                                'document_id': chunk.spd_document_id,
                                'page_number': chunk.page_number or 0,
                                'section_title': chunk.section_title or "",
                                'content_type': chunk.content_type or "text",
                                'word_count': chunk.word_count or 0,
                                'char_count': chunk.char_count or 0
                            },
                            'keyword_score': score,
                            'search_type': 'keyword'
                        }
                        results.append(result)
            
            # Sort by keyword score and return top results
            results.sort(key=lambda x: x['keyword_score'], reverse=True)
            return results[:top_k]
            
        except Exception as e:
            logger.error(f"Error in keyword search: {e}")
            return []
    
    def _extract_keywords(self, query: str) -> List[str]:
        """Extract meaningful keywords from query."""
        # Remove common stop words and extract meaningful terms
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
            'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
            'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
            'should', 'may', 'might', 'can', 'what', 'when', 'where', 'why', 'how'
        }
        
        # Extract words and filter
        words = re.findall(r'\b\w+\b', query.lower())
        keywords = [word for word in words if word not in stop_words and len(word) > 2]
        
        return keywords
    
    def _calculate_keyword_score(self, text: str, keywords: List[str]) -> float:
        """Calculate keyword matching score for text."""
        if not keywords:
            return 0.0
        
        text_lower = text.lower()
        total_score = 0.0
        
        for keyword in keywords:
            # Count exact matches
            exact_matches = text_lower.count(keyword)
            
            # Count partial matches (word contains keyword)
            words = re.findall(r'\b\w+\b', text_lower)
            partial_matches = sum(1 for word in words if keyword in word and word != keyword)
            
            # Calculate score for this keyword
            keyword_score = exact_matches * 1.0 + partial_matches * 0.5
            total_score += keyword_score
        
        # Normalize by text length and number of keywords
        normalized_score = total_score / (len(keywords) * (len(text.split()) / 100))
        return min(normalized_score, 1.0)  # Cap at 1.0
    
    def hybrid_search(self, query: str, health_plan_id: str, 
                     top_k: int = 10) -> List[Dict[str, Any]]:
        """Perform hybrid search combining semantic and keyword search."""
        try:
            # Perform both types of search
            semantic_results = self.semantic_search(query, health_plan_id, top_k)
            keyword_results = self.keyword_search(query, health_plan_id, top_k)
            
            # Combine and deduplicate results
            combined_results = {}
            
            # Add semantic results
            for result in semantic_results:
                chunk_id = result['chunk_id']
                combined_results[chunk_id] = result
                combined_results[chunk_id]['hybrid_score'] = (
                    result['semantic_score'] * self.semantic_weight
                )
            
            # Add keyword results
            for result in keyword_results:
                chunk_id = result['chunk_id']
                if chunk_id in combined_results:
                    # Combine scores
                    combined_results[chunk_id]['hybrid_score'] += (
                        result['keyword_score'] * self.keyword_weight
                    )
                    combined_results[chunk_id]['keyword_score'] = result['keyword_score']
                else:
                    # New result from keyword search
                    combined_results[chunk_id] = result
                    combined_results[chunk_id]['hybrid_score'] = (
                        result['keyword_score'] * self.keyword_weight
                    )
                    combined_results[chunk_id]['semantic_score'] = 0.0
            
            # Sort by hybrid score and return top results
            final_results = list(combined_results.values())
            final_results.sort(key=lambda x: x['hybrid_score'], reverse=True)
            
            return final_results[:top_k]
            
        except Exception as e:
            logger.error(f"Error in hybrid search: {e}")
            return []

class RAGService:
    """Advanced RAG service for SmartSPD v2."""
    
    def __init__(self, openai_api_key: str = None, neo4j_config: Dict[str, str] = None):
        """Initialize the RAG service."""
        self.openai_client = None
        if openai_api_key:
            try:
                self.openai_client = OpenAI(api_key=openai_api_key)
                logger.info("OpenAI client initialized")
            except Exception as e:
                logger.error(f"Failed to initialize OpenAI client: {e}")
        
        # Initialize search engine
        self.search_engine = HybridSearchEngine()
        
        # Initialize knowledge graph service
        self.kg_service = None
        if neo4j_config:
            try:
                self.kg_service = KnowledgeGraphService(
                    neo4j_uri=neo4j_config.get('uri'),
                    neo4j_user=neo4j_config.get('user'),
                    neo4j_password=neo4j_config.get('password')
                )
                logger.info("Knowledge graph service initialized")
            except Exception as e:
                logger.error(f"Failed to initialize knowledge graph service: {e}")
        
        # Query processing settings
        self.max_context_length = 8000
        self.confidence_threshold = 0.3
        self.max_sources = 5
        
    def process_query(self, query: str, health_plan_id: str, user_id: str,
                     session_id: str = None) -> QueryRecord:
        """Process a user query and generate a response."""
        try:
            # Create query record
            query_record = QueryRecord(
                user_id=user_id,
                health_plan_id=health_plan_id,
                session_id=session_id or str(uuid.uuid4()),
                query_text=query,
                status=QueryStatus.PROCESSING.value
            )
            
            db.session.add(query_record)
            db.session.commit()
            
            start_time = datetime.utcnow()
            
            # Analyze query intent
            query_analysis = self._analyze_query_intent(query)
            
            # Retrieve relevant context
            context_results = self._retrieve_context(query, health_plan_id, query_analysis)
            
            # Generate response
            response_data = self._generate_response(query, context_results, query_analysis)
            
            # Calculate response time
            end_time = datetime.utcnow()
            response_time_ms = int((end_time - start_time).total_seconds() * 1000)
            
            # Update query record
            query_record.response_text = response_data['response']
            query_record.confidence_level = response_data['confidence_level']
            query_record.sources_used = response_data['sources']
            query_record.response_time_ms = response_time_ms
            query_record.status = QueryStatus.COMPLETED.value
            query_record.completed_at = end_time
            
            db.session.commit()
            
            logger.info(f"Query processed successfully in {response_time_ms}ms")
            return query_record
            
        except Exception as e:
            logger.error(f"Error processing query: {e}")
            if 'query_record' in locals():
                query_record.status = QueryStatus.FAILED.value
                query_record.error_message = str(e)
                db.session.commit()
            raise
    
    def _analyze_query_intent(self, query: str) -> Dict[str, Any]:
        """Analyze query intent and extract key information."""
        analysis = {
            'intent_type': 'general',
            'benefit_types': [],
            'keywords': [],
            'question_type': 'informational',
            'urgency': 'normal'
        }
        
        try:
            query_lower = query.lower()
            
            # Identify benefit types
            benefit_keywords = {
                'medical': ['medical', 'doctor', 'physician', 'hospital', 'surgery', 'treatment'],
                'dental': ['dental', 'dentist', 'teeth', 'oral'],
                'vision': ['vision', 'eye', 'glasses', 'contacts', 'optometry'],
                'prescription': ['prescription', 'medication', 'drug', 'pharmacy', 'rx'],
                'mental_health': ['mental health', 'therapy', 'counseling', 'psychiatric'],
                'preventive': ['preventive', 'screening', 'checkup', 'wellness', 'vaccination']
            }
            
            for benefit_type, keywords in benefit_keywords.items():
                if any(keyword in query_lower for keyword in keywords):
                    analysis['benefit_types'].append(benefit_type)
            
            # Identify question type
            if any(word in query_lower for word in ['how much', 'cost', 'price', 'fee', 'charge']):
                analysis['question_type'] = 'cost'
            elif any(word in query_lower for word in ['covered', 'cover', 'include', 'benefit']):
                analysis['question_type'] = 'coverage'
            elif any(word in query_lower for word in ['where', 'find', 'locate', 'provider']):
                analysis['question_type'] = 'provider'
            elif any(word in query_lower for word in ['how', 'process', 'procedure', 'steps']):
                analysis['question_type'] = 'process'
            
            # Identify urgency
            if any(word in query_lower for word in ['urgent', 'emergency', 'asap', 'immediately']):
                analysis['urgency'] = 'high'
            elif any(word in query_lower for word in ['soon', 'quickly', 'fast']):
                analysis['urgency'] = 'medium'
            
            # Extract keywords
            analysis['keywords'] = self.search_engine._extract_keywords(query)
            
        except Exception as e:
            logger.warning(f"Error analyzing query intent: {e}")
        
        return analysis
    
    def _retrieve_context(self, query: str, health_plan_id: str, 
                         query_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Retrieve relevant context for the query."""
        try:
            # Perform hybrid search
            search_results = self.search_engine.hybrid_search(
                query, health_plan_id, top_k=10
            )
            
            # Query knowledge graph for structured data
            kg_results = []
            if self.kg_service:
                for benefit_type in query_analysis.get('benefit_types', []):
                    benefits = self.kg_service.query_benefits(
                        health_plan_id, benefit_type, query
                    )
                    kg_results.extend(benefits)
            
            # Combine and rank results
            combined_results = self._combine_and_rank_results(
                search_results, kg_results, query_analysis
            )
            
            return combined_results
            
        except Exception as e:
            logger.error(f"Error retrieving context: {e}")
            return []
    
    def _combine_and_rank_results(self, search_results: List[Dict[str, Any]],
                                 kg_results: List[Dict[str, Any]],
                                 query_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Combine and rank results from different sources."""
        combined_results = []
        
        try:
            # Add search results
            for result in search_results:
                combined_result = {
                    'content': result['content'],
                    'source_type': 'document',
                    'source_id': result['chunk_id'],
                    'relevance_score': result['hybrid_score'],
                    'metadata': result['metadata']
                }
                combined_results.append(combined_result)
            
            # Add knowledge graph results
            for result in kg_results:
                # Convert benefit data to text
                benefit_text = self._format_benefit_as_text(result)
                combined_result = {
                    'content': benefit_text,
                    'source_type': 'knowledge_graph',
                    'source_id': result.get('id', 'unknown'),
                    'relevance_score': 0.8,  # High relevance for structured data
                    'metadata': result
                }
                combined_results.append(combined_result)
            
            # Sort by relevance score
            combined_results.sort(key=lambda x: x['relevance_score'], reverse=True)
            
            # Limit to max sources
            return combined_results[:self.max_sources]
            
        except Exception as e:
            logger.error(f"Error combining and ranking results: {e}")
            return search_results[:self.max_sources]
    
    def _format_benefit_as_text(self, benefit: Dict[str, Any]) -> str:
        """Format benefit data as readable text."""
        try:
            text_parts = []
            
            name = benefit.get('name', 'Unknown Benefit')
            text_parts.append(f"Benefit: {name}")
            
            if benefit.get('description'):
                text_parts.append(f"Description: {benefit['description']}")
            
            if benefit.get('amount'):
                text_parts.append(f"Amount: ${benefit['amount']}")
            
            if benefit.get('percentage'):
                text_parts.append(f"Coverage: {benefit['percentage']}%")
            
            if benefit.get('frequency'):
                text_parts.append(f"Frequency: {benefit['frequency']}")
            
            return " | ".join(text_parts)
            
        except Exception as e:
            logger.warning(f"Error formatting benefit as text: {e}")
            return str(benefit)
    
    def _generate_response(self, query: str, context_results: List[Dict[str, Any]],
                          query_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Generate a response using the retrieved context."""
        try:
            if not self.openai_client:
                return self._generate_fallback_response(context_results)
            
            # Prepare context
            context_text = self._prepare_context_text(context_results)
            
            # Create system prompt
            system_prompt = self._create_system_prompt(query_analysis)
            
            # Create user prompt
            user_prompt = f"""
Context Information:
{context_text}

User Question: {query}

Please provide a comprehensive and accurate answer based on the context information provided. 
If the information is not sufficient to answer the question completely, please indicate what 
additional information might be needed.
"""
            
            # Generate response using OpenAI
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.3,
                max_tokens=1000
            )
            
            response_text = response.choices[0].message.content
            
            # Calculate confidence level
            confidence_level = self._calculate_confidence_level(
                context_results, query_analysis
            )
            
            # Prepare sources
            sources = self._prepare_sources(context_results)
            
            return {
                'response': response_text,
                'confidence_level': confidence_level,
                'sources': sources
            }
            
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return self._generate_fallback_response(context_results)
    
    def _create_system_prompt(self, query_analysis: Dict[str, Any]) -> str:
        """Create a system prompt based on query analysis."""
        base_prompt = """
You are SmartSPD, an AI assistant specialized in health insurance plan benefits and coverage. 
You help users understand their health plan benefits by providing accurate, clear, and helpful information.

Guidelines:
1. Always base your answers on the provided context information
2. Be specific about coverage amounts, percentages, and limitations
3. If information is unclear or missing, acknowledge this
4. Use clear, non-technical language when possible
5. Provide actionable guidance when appropriate
6. Always cite your sources when making specific claims
"""
        
        # Add specific guidance based on query type
        question_type = query_analysis.get('question_type', 'informational')
        
        if question_type == 'cost':
            base_prompt += """
7. For cost-related questions, provide specific dollar amounts, percentages, and any applicable deductibles or copays
8. Explain how costs might vary based on different scenarios (in-network vs out-of-network, etc.)
"""
        elif question_type == 'coverage':
            base_prompt += """
7. For coverage questions, clearly state what is covered and what is not
8. Mention any pre-authorization requirements or limitations
"""
        elif question_type == 'provider':
            base_prompt += """
7. For provider questions, explain how to find in-network providers
8. Mention any referral requirements or restrictions
"""
        
        return base_prompt
    
    def _prepare_context_text(self, context_results: List[Dict[str, Any]]) -> str:
        """Prepare context text from search results."""
        context_parts = []
        current_length = 0
        
        for i, result in enumerate(context_results):
            content = result['content']
            source_info = f"[Source {i+1}: {result['source_type']}]"
            
            context_part = f"{source_info}\n{content}\n"
            
            # Check if adding this would exceed max length
            if current_length + len(context_part) > self.max_context_length:
                break
            
            context_parts.append(context_part)
            current_length += len(context_part)
        
        return "\n".join(context_parts)
    
    def _calculate_confidence_level(self, context_results: List[Dict[str, Any]],
                                   query_analysis: Dict[str, Any]) -> str:
        """Calculate confidence level based on context quality."""
        if not context_results:
            return ConfidenceLevel.LOW.value
        
        # Calculate average relevance score
        avg_relevance = sum(r['relevance_score'] for r in context_results) / len(context_results)
        
        # Check for high-quality sources
        has_structured_data = any(r['source_type'] == 'knowledge_graph' for r in context_results)
        
        # Determine confidence level
        if avg_relevance > 0.7 and has_structured_data:
            return ConfidenceLevel.HIGH.value
        elif avg_relevance > 0.5:
            return ConfidenceLevel.MEDIUM.value
        else:
            return ConfidenceLevel.LOW.value
    
    def _prepare_sources(self, context_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Prepare source information for the response."""
        sources = []
        
        for result in context_results:
            source = {
                'type': result['source_type'],
                'id': result['source_id'],
                'relevance_score': result['relevance_score']
            }
            
            if result['source_type'] == 'document':
                metadata = result['metadata']
                source.update({
                    'page_number': metadata.get('page_number'),
                    'section_title': metadata.get('section_title'),
                    'content_type': metadata.get('content_type')
                })
            elif result['source_type'] == 'knowledge_graph':
                metadata = result['metadata']
                source.update({
                    'benefit_name': metadata.get('name'),
                    'benefit_type': metadata.get('type')
                })
            
            sources.append(source)
        
        return sources
    
    def _generate_fallback_response(self, context_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a fallback response when OpenAI is not available."""
        if not context_results:
            response_text = """
I apologize, but I couldn't find specific information to answer your question in the available documents. 
Please try rephrasing your question or contact your plan administrator for more detailed information.
"""
            confidence_level = ConfidenceLevel.LOW.value
        else:
            # Create a simple response based on context
            response_text = f"""
Based on the available information in your plan documents, here are the relevant details:

{context_results[0]['content'][:500]}...

For more specific information, please refer to your complete plan documents or contact your plan administrator.
"""
            confidence_level = ConfidenceLevel.MEDIUM.value
        
        sources = self._prepare_sources(context_results)
        
        return {
            'response': response_text,
            'confidence_level': confidence_level,
            'sources': sources
        }
    
    def add_feedback(self, query_record_id: str, rating: int, comment: str = None) -> bool:
        """Add user feedback to a query record."""
        try:
            query_record = QueryRecord.query.get(query_record_id)
            if not query_record:
                logger.warning(f"Query record not found: {query_record_id}")
                return False
            
            query_record.feedback_rating = rating
            query_record.feedback_comment = comment
            
            db.session.commit()
            
            logger.info(f"Feedback added to query {query_record_id}: {rating}/5")
            return True
            
        except Exception as e:
            logger.error(f"Error adding feedback: {e}")
            return False
    
    def get_query_history(self, user_id: str, health_plan_id: str = None,
                         limit: int = 50) -> List[QueryRecord]:
        """Get query history for a user."""
        try:
            query = QueryRecord.query.filter_by(user_id=user_id)
            
            if health_plan_id:
                query = query.filter_by(health_plan_id=health_plan_id)
            
            query_records = query.order_by(QueryRecord.created_at.desc()).limit(limit).all()
            
            return query_records
            
        except Exception as e:
            logger.error(f"Error getting query history: {e}")
            return []

# Utility functions

def create_rag_service(openai_api_key: str = None, neo4j_config: Dict[str, str] = None) -> RAGService:
    """Create and return a RAG service instance."""
    return RAGService(openai_api_key, neo4j_config)

def index_health_plan_documents(rag_service: RAGService, health_plan: HealthPlan) -> bool:
    """Index all documents for a health plan in the RAG service."""
    try:
        total_chunks = 0
        
        # Index SPD documents
        for spd_doc in health_plan.spd_documents:
            if spd_doc.processing_status == 'processed' and spd_doc.chunks:
                if rag_service.search_engine.add_document_chunks(spd_doc.chunks):
                    total_chunks += len(spd_doc.chunks)
                    logger.info(f"Indexed {len(spd_doc.chunks)} chunks from {spd_doc.file_name}")
        
        logger.info(f"Successfully indexed {total_chunks} total chunks for health plan: {health_plan.plan_name}")
        return True
        
    except Exception as e:
        logger.error(f"Error indexing health plan documents: {e}")
        return False


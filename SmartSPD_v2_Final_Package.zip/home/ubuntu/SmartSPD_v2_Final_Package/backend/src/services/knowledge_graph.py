"""
SmartSPD v2 - Knowledge Graph Service
====================================

This module provides knowledge graph functionality for storing and querying
health plan benefits and relationships using Neo4j.
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, date
import uuid

try:
    from neo4j import GraphDatabase
    NEO4J_AVAILABLE = True
except ImportError:
    NEO4J_AVAILABLE = False
    logging.warning("Neo4j driver not available. Knowledge graph features will be limited.")

from src.models.smartspd_models import (
    HealthPlan, BPSData, TPAClient, BenefitNode, PlanBenefitRelationship
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class KnowledgeGraphService:
    """Service for managing health plan knowledge graph."""
    
    def __init__(self, neo4j_uri: str = None, neo4j_user: str = None, 
                 neo4j_password: str = None):
        """Initialize the knowledge graph service."""
        self.driver = None
        self.neo4j_available = NEO4J_AVAILABLE
        
        if self.neo4j_available and neo4j_uri and neo4j_user and neo4j_password:
            try:
                self.driver = GraphDatabase.driver(
                    neo4j_uri, 
                    auth=(neo4j_user, neo4j_password)
                )
                # Test connection
                with self.driver.session() as session:
                    session.run("RETURN 1")
                logger.info("Connected to Neo4j database")
            except Exception as e:
                logger.error(f"Failed to connect to Neo4j: {e}")
                self.driver = None
                self.neo4j_available = False
        else:
            logger.warning("Neo4j configuration not provided. Using fallback storage.")
            self.neo4j_available = False
        
        # Fallback storage for when Neo4j is not available
        self.fallback_storage = {
            'tpa_clients': {},
            'health_plans': {},
            'benefits': {},
            'relationships': []
        }
    
    def close(self):
        """Close the Neo4j driver connection."""
        if self.driver:
            self.driver.close()
    
    def create_tpa_client_node(self, tpa_client: TPAClient) -> bool:
        """Create a TPA client node in the knowledge graph."""
        if self.neo4j_available and self.driver:
            return self._create_tpa_client_neo4j(tpa_client)
        else:
            return self._create_tpa_client_fallback(tpa_client)
    
    def _create_tpa_client_neo4j(self, tpa_client: TPAClient) -> bool:
        """Create TPA client node in Neo4j."""
        try:
            with self.driver.session() as session:
                query = """
                MERGE (tpa:TPAClient {id: $id})
                SET tpa.name = $name,
                    tpa.code = $code,
                    tpa.contact_email = $contact_email,
                    tpa.contact_phone = $contact_phone,
                    tpa.address = $address,
                    tpa.settings = $settings,
                    tpa.is_active = $is_active,
                    tpa.created_at = $created_at,
                    tpa.updated_at = $updated_at
                RETURN tpa
                """
                
                result = session.run(query, {
                    'id': tpa_client.id,
                    'name': tpa_client.name,
                    'code': tpa_client.code,
                    'contact_email': tpa_client.contact_email,
                    'contact_phone': tpa_client.contact_phone,
                    'address': json.dumps(tpa_client.address) if tpa_client.address else None,
                    'settings': json.dumps(tpa_client.settings) if tpa_client.settings else None,
                    'is_active': tpa_client.is_active,
                    'created_at': tpa_client.created_at.isoformat(),
                    'updated_at': tpa_client.updated_at.isoformat()
                })
                
                return result.single() is not None
                
        except Exception as e:
            logger.error(f"Error creating TPA client node in Neo4j: {e}")
            return False
    
    def _create_tpa_client_fallback(self, tpa_client: TPAClient) -> bool:
        """Create TPA client in fallback storage."""
        try:
            self.fallback_storage['tpa_clients'][tpa_client.id] = {
                'id': tpa_client.id,
                'name': tpa_client.name,
                'code': tpa_client.code,
                'contact_email': tpa_client.contact_email,
                'contact_phone': tpa_client.contact_phone,
                'address': tpa_client.address,
                'settings': tpa_client.settings,
                'is_active': tpa_client.is_active,
                'created_at': tpa_client.created_at.isoformat(),
                'updated_at': tpa_client.updated_at.isoformat()
            }
            return True
        except Exception as e:
            logger.error(f"Error creating TPA client in fallback storage: {e}")
            return False
    
    def create_health_plan_node(self, health_plan: HealthPlan) -> bool:
        """Create a health plan node in the knowledge graph."""
        if self.neo4j_available and self.driver:
            return self._create_health_plan_neo4j(health_plan)
        else:
            return self._create_health_plan_fallback(health_plan)
    
    def _create_health_plan_neo4j(self, health_plan: HealthPlan) -> bool:
        """Create health plan node in Neo4j."""
        try:
            with self.driver.session() as session:
                query = """
                MATCH (tpa:TPAClient {id: $tpa_client_id})
                MERGE (plan:HealthPlan {id: $id})
                SET plan.plan_name = $plan_name,
                    plan.plan_code = $plan_code,
                    plan.plan_type = $plan_type,
                    plan.effective_date = $effective_date,
                    plan.termination_date = $termination_date,
                    plan.description = $description,
                    plan.is_active = $is_active,
                    plan.created_at = $created_at,
                    plan.updated_at = $updated_at
                MERGE (tpa)-[:MANAGES]->(plan)
                RETURN plan
                """
                
                result = session.run(query, {
                    'id': health_plan.id,
                    'tpa_client_id': health_plan.tpa_client_id,
                    'plan_name': health_plan.plan_name,
                    'plan_code': health_plan.plan_code,
                    'plan_type': health_plan.plan_type,
                    'effective_date': health_plan.effective_date.isoformat(),
                    'termination_date': health_plan.termination_date.isoformat() if health_plan.termination_date else None,
                    'description': health_plan.description,
                    'is_active': health_plan.is_active,
                    'created_at': health_plan.created_at.isoformat(),
                    'updated_at': health_plan.updated_at.isoformat()
                })
                
                return result.single() is not None
                
        except Exception as e:
            logger.error(f"Error creating health plan node in Neo4j: {e}")
            return False
    
    def _create_health_plan_fallback(self, health_plan: HealthPlan) -> bool:
        """Create health plan in fallback storage."""
        try:
            self.fallback_storage['health_plans'][health_plan.id] = {
                'id': health_plan.id,
                'tpa_client_id': health_plan.tpa_client_id,
                'plan_name': health_plan.plan_name,
                'plan_code': health_plan.plan_code,
                'plan_type': health_plan.plan_type,
                'effective_date': health_plan.effective_date.isoformat(),
                'termination_date': health_plan.termination_date.isoformat() if health_plan.termination_date else None,
                'description': health_plan.description,
                'is_active': health_plan.is_active,
                'created_at': health_plan.created_at.isoformat(),
                'updated_at': health_plan.updated_at.isoformat()
            }
            return True
        except Exception as e:
            logger.error(f"Error creating health plan in fallback storage: {e}")
            return False
    
    def populate_benefits_from_bps(self, bps_data: BPSData) -> bool:
        """Populate benefits in the knowledge graph from BPS data."""
        try:
            if not bps_data.structured_data:
                logger.warning("No structured data available in BPS")
                return False
            
            benefits_created = 0
            relationships_created = 0
            
            # Extract benefits from structured data
            benefits = self._extract_benefits_from_bps(bps_data)
            
            # Create benefit nodes
            for benefit in benefits:
                if self._create_benefit_node(benefit):
                    benefits_created += 1
                
                # Create relationship between plan and benefit
                relationship = PlanBenefitRelationship(
                    plan_id=bps_data.health_plan_id,
                    benefit_id=benefit.id,
                    relationship_type="includes"
                )
                
                if self._create_plan_benefit_relationship(relationship):
                    relationships_created += 1
            
            logger.info(f"Created {benefits_created} benefits and {relationships_created} relationships")
            return True
            
        except Exception as e:
            logger.error(f"Error populating benefits from BPS: {e}")
            return False
    
    def _extract_benefits_from_bps(self, bps_data: BPSData) -> List[BenefitNode]:
        """Extract benefit nodes from BPS structured data."""
        benefits = []
        
        try:
            structured_data = bps_data.structured_data
            worksheets = structured_data.get('worksheets', [])
            
            for worksheet in worksheets:
                sheet_name = worksheet.get('name', '').lower()
                data = worksheet.get('data', [])
                
                # Determine benefit category from sheet name
                benefit_type = self._determine_benefit_type(sheet_name)
                
                # Extract benefits from worksheet data
                sheet_benefits = self._extract_benefits_from_worksheet(data, benefit_type)
                benefits.extend(sheet_benefits)
                
        except Exception as e:
            logger.error(f"Error extracting benefits from BPS: {e}")
        
        return benefits
    
    def _determine_benefit_type(self, sheet_name: str) -> str:
        """Determine benefit type from worksheet name."""
        sheet_name = sheet_name.lower()
        
        if 'medical' in sheet_name:
            return 'medical'
        elif 'dental' in sheet_name:
            return 'dental'
        elif 'vision' in sheet_name:
            return 'vision'
        elif 'prescription' in sheet_name or 'rx' in sheet_name:
            return 'prescription'
        elif 'mental' in sheet_name:
            return 'mental_health'
        elif 'preventive' in sheet_name:
            return 'preventive'
        else:
            return 'medical'  # Default
    
    def _extract_benefits_from_worksheet(self, data: List[Dict[str, Any]], 
                                       benefit_type: str) -> List[BenefitNode]:
        """Extract benefits from worksheet data."""
        benefits = []
        
        try:
            for row in data:
                # Look for benefit information in the row
                benefit_name = self._extract_benefit_name(row)
                if not benefit_name:
                    continue
                
                # Extract benefit details
                amount = self._extract_amount(row)
                percentage = self._extract_percentage(row)
                frequency = self._extract_frequency(row)
                description = self._extract_description(row)
                
                # Create benefit node
                benefit = BenefitNode(
                    benefit_id=str(uuid.uuid4()),
                    benefit_type=benefit_type,
                    name=benefit_name,
                    description=description,
                    amount=amount,
                    percentage=percentage,
                    frequency=frequency
                )
                
                benefits.append(benefit)
                
        except Exception as e:
            logger.error(f"Error extracting benefits from worksheet: {e}")
        
        return benefits
    
    def _extract_benefit_name(self, row: Dict[str, Any]) -> Optional[str]:
        """Extract benefit name from a data row."""
        # Look for common benefit name fields
        name_fields = ['benefit', 'service', 'coverage', 'benefit_name', 'service_type']
        
        for field in name_fields:
            for key, value in row.items():
                if field in key.lower() and value and str(value).strip():
                    return str(value).strip()
        
        # If no specific field found, use the first non-empty value
        for key, value in row.items():
            if value and str(value).strip() and not str(value).replace('$', '').replace('%', '').replace(',', '').isdigit():
                return str(value).strip()
        
        return None
    
    def _extract_amount(self, row: Dict[str, Any]) -> Optional[float]:
        """Extract monetary amount from a data row."""
        for key, value in row.items():
            if value and '$' in str(value):
                try:
                    # Extract numeric value from currency string
                    amount_str = str(value).replace('$', '').replace(',', '').strip()
                    return float(amount_str)
                except ValueError:
                    continue
        return None
    
    def _extract_percentage(self, row: Dict[str, Any]) -> Optional[float]:
        """Extract percentage from a data row."""
        for key, value in row.items():
            if value and '%' in str(value):
                try:
                    # Extract numeric value from percentage string
                    percent_str = str(value).replace('%', '').strip()
                    return float(percent_str)
                except ValueError:
                    continue
        return None
    
    def _extract_frequency(self, row: Dict[str, Any]) -> Optional[str]:
        """Extract frequency information from a data row."""
        frequency_keywords = ['annual', 'monthly', 'per visit', 'per day', 'lifetime']
        
        for key, value in row.items():
            if value:
                value_str = str(value).lower()
                for keyword in frequency_keywords:
                    if keyword in value_str:
                        return keyword
        
        return None
    
    def _extract_description(self, row: Dict[str, Any]) -> Optional[str]:
        """Extract description from a data row."""
        desc_fields = ['description', 'notes', 'details', 'comments']
        
        for field in desc_fields:
            for key, value in row.items():
                if field in key.lower() and value and str(value).strip():
                    return str(value).strip()
        
        return None
    
    def _create_benefit_node(self, benefit: BenefitNode) -> bool:
        """Create a benefit node in the knowledge graph."""
        if self.neo4j_available and self.driver:
            return self._create_benefit_node_neo4j(benefit)
        else:
            return self._create_benefit_node_fallback(benefit)
    
    def _create_benefit_node_neo4j(self, benefit: BenefitNode) -> bool:
        """Create benefit node in Neo4j."""
        try:
            with self.driver.session() as session:
                query = """
                MERGE (benefit:Benefit {id: $id})
                SET benefit.type = $type,
                    benefit.name = $name,
                    benefit.description = $description,
                    benefit.amount = $amount,
                    benefit.percentage = $percentage,
                    benefit.frequency = $frequency,
                    benefit.conditions = $conditions,
                    benefit.exclusions = $exclusions
                RETURN benefit
                """
                
                result = session.run(query, {
                    'id': benefit.id,
                    'type': benefit.type,
                    'name': benefit.name,
                    'description': benefit.description,
                    'amount': benefit.amount,
                    'percentage': benefit.percentage,
                    'frequency': benefit.frequency,
                    'conditions': json.dumps(benefit.conditions),
                    'exclusions': json.dumps(benefit.exclusions)
                })
                
                return result.single() is not None
                
        except Exception as e:
            logger.error(f"Error creating benefit node in Neo4j: {e}")
            return False
    
    def _create_benefit_node_fallback(self, benefit: BenefitNode) -> bool:
        """Create benefit node in fallback storage."""
        try:
            self.fallback_storage['benefits'][benefit.id] = benefit.to_dict()
            return True
        except Exception as e:
            logger.error(f"Error creating benefit node in fallback storage: {e}")
            return False
    
    def _create_plan_benefit_relationship(self, relationship: PlanBenefitRelationship) -> bool:
        """Create a relationship between plan and benefit."""
        if self.neo4j_available and self.driver:
            return self._create_plan_benefit_relationship_neo4j(relationship)
        else:
            return self._create_plan_benefit_relationship_fallback(relationship)
    
    def _create_plan_benefit_relationship_neo4j(self, relationship: PlanBenefitRelationship) -> bool:
        """Create plan-benefit relationship in Neo4j."""
        try:
            with self.driver.session() as session:
                query = """
                MATCH (plan:HealthPlan {id: $plan_id})
                MATCH (benefit:Benefit {id: $benefit_id})
                MERGE (plan)-[r:INCLUDES]->(benefit)
                SET r.relationship_type = $relationship_type,
                    r.effective_date = $effective_date,
                    r.termination_date = $termination_date,
                    r.conditions = $conditions
                RETURN r
                """
                
                result = session.run(query, {
                    'plan_id': relationship.plan_id,
                    'benefit_id': relationship.benefit_id,
                    'relationship_type': relationship.relationship_type,
                    'effective_date': relationship.effective_date.isoformat() if relationship.effective_date else None,
                    'termination_date': relationship.termination_date.isoformat() if relationship.termination_date else None,
                    'conditions': json.dumps(relationship.conditions)
                })
                
                return result.single() is not None
                
        except Exception as e:
            logger.error(f"Error creating plan-benefit relationship in Neo4j: {e}")
            return False
    
    def _create_plan_benefit_relationship_fallback(self, relationship: PlanBenefitRelationship) -> bool:
        """Create plan-benefit relationship in fallback storage."""
        try:
            self.fallback_storage['relationships'].append(relationship.to_dict())
            return True
        except Exception as e:
            logger.error(f"Error creating plan-benefit relationship in fallback storage: {e}")
            return False
    
    def query_benefits(self, plan_id: str, benefit_type: str = None, 
                      search_term: str = None) -> List[Dict[str, Any]]:
        """Query benefits for a specific plan."""
        if self.neo4j_available and self.driver:
            return self._query_benefits_neo4j(plan_id, benefit_type, search_term)
        else:
            return self._query_benefits_fallback(plan_id, benefit_type, search_term)
    
    def _query_benefits_neo4j(self, plan_id: str, benefit_type: str = None,
                             search_term: str = None) -> List[Dict[str, Any]]:
        """Query benefits from Neo4j."""
        try:
            with self.driver.session() as session:
                query = """
                MATCH (plan:HealthPlan {id: $plan_id})-[:INCLUDES]->(benefit:Benefit)
                """
                
                params = {'plan_id': plan_id}
                
                if benefit_type:
                    query += " WHERE benefit.type = $benefit_type"
                    params['benefit_type'] = benefit_type
                
                if search_term:
                    if benefit_type:
                        query += " AND (benefit.name CONTAINS $search_term OR benefit.description CONTAINS $search_term)"
                    else:
                        query += " WHERE (benefit.name CONTAINS $search_term OR benefit.description CONTAINS $search_term)"
                    params['search_term'] = search_term
                
                query += " RETURN benefit"
                
                result = session.run(query, params)
                
                benefits = []
                for record in result:
                    benefit_data = dict(record['benefit'])
                    benefits.append(benefit_data)
                
                return benefits
                
        except Exception as e:
            logger.error(f"Error querying benefits from Neo4j: {e}")
            return []
    
    def _query_benefits_fallback(self, plan_id: str, benefit_type: str = None,
                                search_term: str = None) -> List[Dict[str, Any]]:
        """Query benefits from fallback storage."""
        try:
            # Find relationships for this plan
            plan_benefits = []
            for relationship in self.fallback_storage['relationships']:
                if relationship['plan_id'] == plan_id:
                    benefit_id = relationship['benefit_id']
                    if benefit_id in self.fallback_storage['benefits']:
                        benefit = self.fallback_storage['benefits'][benefit_id]
                        
                        # Apply filters
                        if benefit_type and benefit.get('type') != benefit_type:
                            continue
                        
                        if search_term:
                            name = benefit.get('name', '').lower()
                            description = benefit.get('description', '').lower()
                            if search_term.lower() not in name and search_term.lower() not in description:
                                continue
                        
                        plan_benefits.append(benefit)
            
            return plan_benefits
            
        except Exception as e:
            logger.error(f"Error querying benefits from fallback storage: {e}")
            return []
    
    def get_plan_summary(self, plan_id: str) -> Dict[str, Any]:
        """Get a comprehensive summary of a health plan."""
        try:
            benefits = self.query_benefits(plan_id)
            
            summary = {
                'plan_id': plan_id,
                'total_benefits': len(benefits),
                'benefit_categories': {},
                'key_benefits': {
                    'deductibles': [],
                    'copays': [],
                    'coinsurance': [],
                    'out_of_pocket_maximums': []
                }
            }
            
            # Categorize benefits
            for benefit in benefits:
                benefit_type = benefit.get('type', 'unknown')
                if benefit_type not in summary['benefit_categories']:
                    summary['benefit_categories'][benefit_type] = 0
                summary['benefit_categories'][benefit_type] += 1
                
                # Identify key benefit types
                name = benefit.get('name', '').lower()
                if 'deductible' in name:
                    summary['key_benefits']['deductibles'].append(benefit)
                elif 'copay' in name:
                    summary['key_benefits']['copays'].append(benefit)
                elif 'coinsurance' in name:
                    summary['key_benefits']['coinsurance'].append(benefit)
                elif 'out of pocket' in name or 'maximum' in name:
                    summary['key_benefits']['out_of_pocket_maximums'].append(benefit)
            
            return summary
            
        except Exception as e:
            logger.error(f"Error getting plan summary: {e}")
            return {}
    
    def initialize_schema(self):
        """Initialize the Neo4j schema with constraints and indexes."""
        if not self.neo4j_available or not self.driver:
            logger.warning("Neo4j not available, skipping schema initialization")
            return
        
        try:
            with self.driver.session() as session:
                # Create constraints
                constraints = [
                    "CREATE CONSTRAINT tpa_client_id IF NOT EXISTS FOR (tpa:TPAClient) REQUIRE tpa.id IS UNIQUE",
                    "CREATE CONSTRAINT health_plan_id IF NOT EXISTS FOR (plan:HealthPlan) REQUIRE plan.id IS UNIQUE",
                    "CREATE CONSTRAINT benefit_id IF NOT EXISTS FOR (benefit:Benefit) REQUIRE benefit.id IS UNIQUE"
                ]
                
                for constraint in constraints:
                    try:
                        session.run(constraint)
                    except Exception as e:
                        logger.debug(f"Constraint may already exist: {e}")
                
                # Create indexes
                indexes = [
                    "CREATE INDEX tpa_client_code IF NOT EXISTS FOR (tpa:TPAClient) ON (tpa.code)",
                    "CREATE INDEX health_plan_code IF NOT EXISTS FOR (plan:HealthPlan) ON (plan.plan_code)",
                    "CREATE INDEX benefit_type IF NOT EXISTS FOR (benefit:Benefit) ON (benefit.type)",
                    "CREATE INDEX benefit_name IF NOT EXISTS FOR (benefit:Benefit) ON (benefit.name)"
                ]
                
                for index in indexes:
                    try:
                        session.run(index)
                    except Exception as e:
                        logger.debug(f"Index may already exist: {e}")
                
                logger.info("Neo4j schema initialized successfully")
                
        except Exception as e:
            logger.error(f"Error initializing Neo4j schema: {e}")

# Utility functions

def create_knowledge_graph_service(neo4j_uri: str = None, neo4j_user: str = None,
                                 neo4j_password: str = None) -> KnowledgeGraphService:
    """Create and return a knowledge graph service instance."""
    return KnowledgeGraphService(neo4j_uri, neo4j_user, neo4j_password)

def populate_knowledge_graph_from_health_plan(kg_service: KnowledgeGraphService,
                                            health_plan: HealthPlan) -> bool:
    """Populate knowledge graph with data from a health plan."""
    try:
        # Create TPA client node
        if not kg_service.create_tpa_client_node(health_plan.tpa_client):
            logger.warning("Failed to create TPA client node")
        
        # Create health plan node
        if not kg_service.create_health_plan_node(health_plan):
            logger.error("Failed to create health plan node")
            return False
        
        # Populate benefits from BPS data
        for bps_data in health_plan.bps_data:
            if bps_data.processing_status == 'processed':
                if not kg_service.populate_benefits_from_bps(bps_data):
                    logger.warning(f"Failed to populate benefits from BPS: {bps_data.file_name}")
        
        logger.info(f"Successfully populated knowledge graph for health plan: {health_plan.plan_name}")
        return True
        
    except Exception as e:
        logger.error(f"Error populating knowledge graph: {e}")
        return False


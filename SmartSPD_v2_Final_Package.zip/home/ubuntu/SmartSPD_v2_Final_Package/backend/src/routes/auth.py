"""
SmartSPD v2 - Authentication API Routes
Handles user registration, login, logout, and session management.
"""

from flask import Blueprint, request, jsonify, session
from services.auth_service import AuthService
from models.database import get_db_session
from datetime import datetime
import logging

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')
logger = logging.getLogger(__name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    """Register a new user."""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['email', 'password', 'name', 'organization']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'message': f'Missing required field: {field}'
                }), 400
        
        db = get_db_session()
        auth_service = AuthService(db)
        
        success, message, user = auth_service.register_user(
            email=data['email'],
            password=data['password'],
            name=data['name'],
            organization=data['organization'],
            role=data.get('role', 'member')
        )
        
        if success:
            # Create session
            user_session = auth_service.create_session(
                user=user,
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent')
            )
            
            # Generate JWT token
            jwt_token = auth_service.generate_jwt_token(
                user_id=user.id,
                email=user.email,
                role=user.role
            )
            
            # Get user's health plans
            health_plans = auth_service.get_user_health_plans(user.id)
            
            return jsonify({
                'success': True,
                'message': message,
                'user': {
                    'id': user['id'],
                    'email': user['email'],
                    'name': user['name'],
                    'role': user['role'],
                    'organization': user['organization']
                },
                'health_plans': [
                    {
                        'id': plan['id'],
                        'plan_name': plan['plan_name'],
                        'plan_code': plan['plan_code'],
                        'plan_type': plan['plan_type']
                    } for plan in health_plans
                ],
                'session_token': user_session['session_token'],
                'jwt_token': jwt_token
            }), 201
        else:
            return jsonify({
                'success': False,
                'message': message
            }), 400
            
    except Exception as e:
        logger.error(f"Registration error: {e}")
        return jsonify({
            'success': False,
            'message': 'Registration failed due to server error'
        }), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """Authenticate user and create session."""
    try:
        data = request.get_json()
        
        if not data.get('email') or not data.get('password'):
            return jsonify({
                'success': False,
                'message': 'Email and password are required'
            }), 400
        
        db = get_db_session()
        auth_service = AuthService(db)
        
        success, message, user = auth_service.authenticate_user(
            email=data['email'],
            password=data['password']
        )
        
        if success:
            # Create session
            user_session = auth_service.create_session(
                user=user,
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent')
            )
            
            # Generate JWT token
            jwt_token = auth_service.generate_jwt_token(
                user_id=user['id'],
                email=user['email'],
                role=user['role']
            )
            
            # Get user's health plans
            health_plans = auth_service.get_user_health_plans(user['id'])
            
            return jsonify({
                'success': True,
                'message': message,
                'user': {
                    'id': user['id'],
                    'email': user['email'],
                    'name': user['name'],
                    'role': user['role'],
                    'organization': user['organization']
                },
                'health_plans': [
                    {
                        'id': plan['id'],
                        'plan_name': plan['plan_name'],
                        'plan_code': plan['plan_code'],
                        'plan_type': plan['plan_type']
                    } for plan in health_plans
                ],
                'session_token': user_session['session_token'],
                'jwt_token': jwt_token
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': message
            }), 401
            
    except Exception as e:
        logger.error(f"Login error: {e}")
        return jsonify({
            'success': False,
            'message': 'Login failed due to server error'
        }), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    """Logout user and invalidate session."""
    try:
        data = request.get_json()
        session_token = data.get('session_token')
        
        if not session_token:
            return jsonify({
                'success': False,
                'message': 'Session token is required'
            }), 400
        
        db = get_db_session()
        auth_service = AuthService(db)
        
        success = auth_service.invalidate_session(session_token)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Logged out successfully'
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'Invalid session token'
            }), 400
            
    except Exception as e:
        logger.error(f"Logout error: {e}")
        return jsonify({
            'success': False,
            'message': 'Logout failed due to server error'
        }), 500

@auth_bp.route('/verify', methods=['POST'])
def verify_session():
    """Verify session token and return user info."""
    try:
        data = request.get_json()
        session_token = data.get('session_token')
        
        if not session_token:
            return jsonify({
                'success': False,
                'message': 'Session token is required'
            }), 400
        
        db = get_db_session()
        auth_service = AuthService(db)
        
        user_session = auth_service.get_active_session(session_token)
        
        if user_session:
            user = user_session['user']
            health_plans = auth_service.get_user_health_plans(user['id'])
            
            # Refresh session
            auth_service.refresh_session(session_token)
            
            return jsonify({
                'success': True,
                'user': {
                    'id': user['id'],
                    'email': user['email'],
                    'name': user['name'],
                    'role': user['role'],
                    'organization': user['organization']
                },
                'health_plans': [
                    {
                        'id': plan['id'],
                        'plan_name': plan['plan_name'],
                        'plan_code': plan['plan_code'],
                        'plan_type': plan['plan_type']
                    } for plan in health_plans
                ]
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'Invalid or expired session'
            }), 401
            
    except Exception as e:
        logger.error(f"Session verification error: {e}")
        return jsonify({
            'success': False,
            'message': 'Session verification failed'
        }), 500

@auth_bp.route('/refresh', methods=['POST'])
def refresh_session():
    """Refresh user session."""
    try:
        data = request.get_json()
        session_token = data.get('session_token')
        
        if not session_token:
            return jsonify({
                'success': False,
                'message': 'Session token is required'
            }), 400
        
        db = get_db_session()
        auth_service = AuthService(db)
        
        user_session = auth_service.refresh_session(session_token)
        
        if user_session:
            return jsonify({
                'success': True,
                'message': 'Session refreshed successfully',
                'expires_at': user_session.expires_at.isoformat()
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'Invalid or expired session'
            }), 401
            
    except Exception as e:
        logger.error(f"Session refresh error: {e}")
        return jsonify({
            'success': False,
            'message': 'Session refresh failed'
        }), 500


"""
SmartSPD v2 - Document Management Routes
=======================================

This module provides API endpoints for document upload, processing, and management.
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, List
import uuid

from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge

from src.models.smartspd_models import (
    HealthPlan, SPDDocument, BPSData, DocumentStatus, 
    SmartSPDUser, TPAClient, db
)
from src.services.document_processor import DocumentProcessor
from src.services.knowledge_graph import KnowledgeGraphService
from src.services.rag_service import RAGService, index_health_plan_documents

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create blueprint
documents_bp = Blueprint('documents', __name__)

# Configuration
UPLOAD_FOLDER = '/tmp/smartspd_uploads'
ALLOWED_EXTENSIONS = {'pdf', 'xlsx', 'xls'}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_file_type(filename):
    """Determine file type from extension."""
    if filename.lower().endswith('.pdf'):
        return 'spd'
    elif filename.lower().endswith(('.xlsx', '.xls')):
        return 'bps'
    return 'unknown'

@documents_bp.route('/health-plans', methods=['GET'])
def get_health_plans():
    """Get all health plans accessible to the user."""
    try:
        # In a real implementation, filter by user permissions
        health_plans = HealthPlan.query.filter_by(is_active=True).all()
        
        plans_data = []
        for plan in health_plans:
            plan_data = {
                'id': plan.id,
                'plan_name': plan.plan_name,
                'plan_code': plan.plan_code,
                'plan_type': plan.plan_type,
                'effective_date': plan.effective_date.isoformat(),
                'termination_date': plan.termination_date.isoformat() if plan.termination_date else None,
                'description': plan.description,
                'tpa_client': {
                    'id': plan.tpa_client.id,
                    'name': plan.tpa_client.name,
                    'code': plan.tpa_client.code
                },
                'document_counts': {
                    'spd_documents': len(plan.spd_documents),
                    'bps_documents': len(plan.bps_data)
                }
            }
            plans_data.append(plan_data)
        
        return jsonify({
            'success': True,
            'health_plans': plans_data
        })
        
    except Exception as e:
        logger.error(f"Error getting health plans: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve health plans'
        }), 500

@documents_bp.route('/health-plans/<plan_id>/documents', methods=['GET'])
def get_plan_documents(plan_id):
    """Get all documents for a specific health plan."""
    try:
        health_plan = HealthPlan.query.get(plan_id)
        if not health_plan:
            return jsonify({
                'success': False,
                'error': 'Health plan not found'
            }), 404
        
        # Get SPD documents
        spd_docs = []
        for doc in health_plan.spd_documents:
            spd_data = {
                'id': doc.id,
                'file_name': doc.file_name,
                'file_size': doc.file_size,
                'upload_date': doc.upload_date.isoformat(),
                'processed_date': doc.processed_date.isoformat() if doc.processed_date else None,
                'processing_status': doc.processing_status,
                'chunk_count': doc.chunk_count,
                'page_count': doc.page_count,
                'version': doc.version,
                'is_current': doc.is_current
            }
            spd_docs.append(spd_data)
        
        # Get BPS documents
        bps_docs = []
        for doc in health_plan.bps_data:
            bps_data = {
                'id': doc.id,
                'file_name': doc.file_name,
                'upload_date': doc.upload_date.isoformat(),
                'processed_date': doc.processed_date.isoformat() if doc.processed_date else None,
                'processing_status': doc.processing_status,
                'worksheet_count': doc.worksheet_count,
                'version': doc.version,
                'is_current': doc.is_current
            }
            bps_docs.append(bps_data)
        
        return jsonify({
            'success': True,
            'health_plan': {
                'id': health_plan.id,
                'plan_name': health_plan.plan_name,
                'plan_code': health_plan.plan_code
            },
            'spd_documents': spd_docs,
            'bps_documents': bps_docs
        })
        
    except Exception as e:
        logger.error(f"Error getting plan documents: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve documents'
        }), 500

@documents_bp.route('/upload', methods=['POST'])
def upload_document():
    """Upload and process a document."""
    try:
        # Check if file is present
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'error': 'No file provided'
            }), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({
                'success': False,
                'error': 'No file selected'
            }), 400
        
        # Get additional parameters
        health_plan_id = request.form.get('health_plan_id')
        if not health_plan_id:
            return jsonify({
                'success': False,
                'error': 'Health plan ID is required'
            }), 400
        
        # Verify health plan exists
        health_plan = HealthPlan.query.get(health_plan_id)
        if not health_plan:
            return jsonify({
                'success': False,
                'error': 'Health plan not found'
            }), 404
        
        # Check file type
        if not allowed_file(file.filename):
            return jsonify({
                'success': False,
                'error': 'File type not allowed. Please upload PDF or Excel files.'
            }), 400
        
        # Check file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)
        
        if file_size > MAX_FILE_SIZE:
            return jsonify({
                'success': False,
                'error': f'File too large. Maximum size is {MAX_FILE_SIZE // (1024*1024)}MB.'
            }), 400
        
        # Save file
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        unique_filename = f"{timestamp}_{filename}"
        file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        
        file.save(file_path)
        
        # Determine file type and process
        file_type = get_file_type(filename)
        
        if file_type == 'spd':
            result = process_spd_document(file_path, health_plan_id)
        elif file_type == 'bps':
            result = process_bps_document(file_path, health_plan_id)
        else:
            return jsonify({
                'success': False,
                'error': 'Unsupported file type'
            }), 400
        
        return jsonify(result)
        
    except RequestEntityTooLarge:
        return jsonify({
            'success': False,
            'error': 'File too large'
        }), 413
    except Exception as e:
        logger.error(f"Error uploading document: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to upload document'
        }), 500

def process_spd_document(file_path: str, health_plan_id: str) -> Dict[str, Any]:
    """Process an SPD document."""
    try:
        # Get OpenAI API key from environment
        openai_api_key = os.environ.get('OPENAI_API_KEY')
        
        # Initialize document processor
        processor = DocumentProcessor(openai_api_key)
        
        # Process the document
        spd_doc = processor.process_spd_document(file_path, health_plan_id)
        
        # Index in RAG service
        try:
            rag_service = RAGService(openai_api_key)
            if spd_doc.chunks:
                rag_service.search_engine.add_document_chunks(spd_doc.chunks)
                logger.info(f"Indexed {len(spd_doc.chunks)} chunks in RAG service")
        except Exception as e:
            logger.warning(f"Failed to index document in RAG service: {e}")
        
        return {
            'success': True,
            'document_id': spd_doc.id,
            'file_name': spd_doc.file_name,
            'processing_status': spd_doc.processing_status,
            'chunk_count': spd_doc.chunk_count,
            'page_count': spd_doc.page_count,
            'message': 'SPD document processed successfully'
        }
        
    except Exception as e:
        logger.error(f"Error processing SPD document: {e}")
        return {
            'success': False,
            'error': f'Failed to process SPD document: {str(e)}'
        }

def process_bps_document(file_path: str, health_plan_id: str) -> Dict[str, Any]:
    """Process a BPS document."""
    try:
        # Initialize document processor
        processor = DocumentProcessor()
        
        # Process the document
        bps_doc = processor.process_bps_document(file_path, health_plan_id)
        
        # Populate knowledge graph
        try:
            neo4j_config = {
                'uri': os.environ.get('NEO4J_URI'),
                'user': os.environ.get('NEO4J_USER'),
                'password': os.environ.get('NEO4J_PASSWORD')
            }
            
            if all(neo4j_config.values()):
                kg_service = KnowledgeGraphService(**neo4j_config)
                kg_service.populate_benefits_from_bps(bps_doc)
                logger.info("Populated knowledge graph with BPS data")
        except Exception as e:
            logger.warning(f"Failed to populate knowledge graph: {e}")
        
        return {
            'success': True,
            'document_id': bps_doc.id,
            'file_name': bps_doc.file_name,
            'processing_status': bps_doc.processing_status,
            'worksheet_count': bps_doc.worksheet_count,
            'benefits_summary': bps_doc.benefits_summary,
            'message': 'BPS document processed successfully'
        }
        
    except Exception as e:
        logger.error(f"Error processing BPS document: {e}")
        return {
            'success': False,
            'error': f'Failed to process BPS document: {str(e)}'
        }

@documents_bp.route('/documents/<document_id>/status', methods=['GET'])
def get_document_status(document_id):
    """Get the processing status of a document."""
    try:
        # Try to find as SPD document first
        spd_doc = SPDDocument.query.get(document_id)
        if spd_doc:
            return jsonify({
                'success': True,
                'document_id': spd_doc.id,
                'document_type': 'spd',
                'file_name': spd_doc.file_name,
                'processing_status': spd_doc.processing_status,
                'processing_error': spd_doc.processing_error,
                'chunk_count': spd_doc.chunk_count,
                'page_count': spd_doc.page_count,
                'upload_date': spd_doc.upload_date.isoformat(),
                'processed_date': spd_doc.processed_date.isoformat() if spd_doc.processed_date else None
            })
        
        # Try to find as BPS document
        bps_doc = BPSData.query.get(document_id)
        if bps_doc:
            return jsonify({
                'success': True,
                'document_id': bps_doc.id,
                'document_type': 'bps',
                'file_name': bps_doc.file_name,
                'processing_status': bps_doc.processing_status,
                'worksheet_count': bps_doc.worksheet_count,
                'upload_date': bps_doc.upload_date.isoformat(),
                'processed_date': bps_doc.processed_date.isoformat() if bps_doc.processed_date else None
            })
        
        return jsonify({
            'success': False,
            'error': 'Document not found'
        }), 404
        
    except Exception as e:
        logger.error(f"Error getting document status: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve document status'
        }), 500

@documents_bp.route('/documents/<document_id>/chunks', methods=['GET'])
def get_document_chunks(document_id):
    """Get chunks for an SPD document."""
    try:
        spd_doc = SPDDocument.query.get(document_id)
        if not spd_doc:
            return jsonify({
                'success': False,
                'error': 'SPD document not found'
            }), 404
        
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Get chunks with pagination
        chunks_query = spd_doc.chunks.order_by('chunk_index')
        chunks_paginated = chunks_query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        chunks_data = []
        for chunk in chunks_paginated.items:
            chunk_data = {
                'id': chunk.id,
                'chunk_index': chunk.chunk_index,
                'content': chunk.content[:500] + '...' if len(chunk.content) > 500 else chunk.content,
                'content_type': chunk.content_type,
                'page_number': chunk.page_number,
                'section_title': chunk.section_title,
                'word_count': chunk.word_count,
                'char_count': chunk.char_count,
                'has_embedding': chunk.embedding_vector is not None
            }
            chunks_data.append(chunk_data)
        
        return jsonify({
            'success': True,
            'document_id': document_id,
            'chunks': chunks_data,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': chunks_paginated.total,
                'pages': chunks_paginated.pages,
                'has_next': chunks_paginated.has_next,
                'has_prev': chunks_paginated.has_prev
            }
        })
        
    except Exception as e:
        logger.error(f"Error getting document chunks: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve document chunks'
        }), 500

@documents_bp.route('/documents/<document_id>/reprocess', methods=['POST'])
def reprocess_document(document_id):
    """Reprocess a document."""
    try:
        # Try to find as SPD document first
        spd_doc = SPDDocument.query.get(document_id)
        if spd_doc:
            if not os.path.exists(spd_doc.file_path):
                return jsonify({
                    'success': False,
                    'error': 'Original file not found'
                }), 404
            
            result = process_spd_document(spd_doc.file_path, spd_doc.health_plan_id)
            return jsonify(result)
        
        # Try to find as BPS document
        bps_doc = BPSData.query.get(document_id)
        if bps_doc:
            if not os.path.exists(bps_doc.file_path):
                return jsonify({
                    'success': False,
                    'error': 'Original file not found'
                }), 404
            
            result = process_bps_document(bps_doc.file_path, bps_doc.health_plan_id)
            return jsonify(result)
        
        return jsonify({
            'success': False,
            'error': 'Document not found'
        }), 404
        
    except Exception as e:
        logger.error(f"Error reprocessing document: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to reprocess document'
        }), 500

@documents_bp.route('/documents/<document_id>', methods=['DELETE'])
def delete_document(document_id):
    """Delete a document."""
    try:
        # Try to find as SPD document first
        spd_doc = SPDDocument.query.get(document_id)
        if spd_doc:
            # Delete file if it exists
            if os.path.exists(spd_doc.file_path):
                os.remove(spd_doc.file_path)
            
            # Delete from database (cascades to chunks)
            db.session.delete(spd_doc)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'SPD document deleted successfully'
            })
        
        # Try to find as BPS document
        bps_doc = BPSData.query.get(document_id)
        if bps_doc:
            # Delete file if it exists
            if os.path.exists(bps_doc.file_path):
                os.remove(bps_doc.file_path)
            
            # Delete from database
            db.session.delete(bps_doc)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'BPS document deleted successfully'
            })
        
        return jsonify({
            'success': False,
            'error': 'Document not found'
        }), 404
        
    except Exception as e:
        logger.error(f"Error deleting document: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to delete document'
        }), 500

@documents_bp.route('/health-plans/<plan_id>/reindex', methods=['POST'])
def reindex_health_plan(plan_id):
    """Reindex all documents for a health plan in the RAG service."""
    try:
        health_plan = HealthPlan.query.get(plan_id)
        if not health_plan:
            return jsonify({
                'success': False,
                'error': 'Health plan not found'
            }), 404
        
        # Initialize RAG service
        openai_api_key = os.environ.get('OPENAI_API_KEY')
        rag_service = RAGService(openai_api_key)
        
        # Reindex documents
        success = index_health_plan_documents(rag_service, health_plan)
        
        if success:
            return jsonify({
                'success': True,
                'message': f'Successfully reindexed documents for {health_plan.plan_name}'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to reindex documents'
            }), 500
        
    except Exception as e:
        logger.error(f"Error reindexing health plan: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to reindex health plan'
        }), 500

@documents_bp.route('/statistics', methods=['GET'])
def get_statistics():
    """Get document processing statistics."""
    try:
        # Get overall statistics
        total_spd_docs = SPDDocument.query.count()
        total_bps_docs = BPSData.query.count()
        processed_spd_docs = SPDDocument.query.filter_by(processing_status='processed').count()
        processed_bps_docs = BPSData.query.filter_by(processing_status='processed').count()
        
        # Get statistics by health plan
        health_plans = HealthPlan.query.filter_by(is_active=True).all()
        plan_stats = []
        
        for plan in health_plans:
            plan_stat = {
                'plan_id': plan.id,
                'plan_name': plan.plan_name,
                'spd_documents': len(plan.spd_documents),
                'bps_documents': len(plan.bps_data),
                'processed_spd': len([doc for doc in plan.spd_documents if doc.processing_status == 'processed']),
                'processed_bps': len([doc for doc in plan.bps_data if doc.processing_status == 'processed']),
                'total_chunks': sum(doc.chunk_count or 0 for doc in plan.spd_documents)
            }
            plan_stats.append(plan_stat)
        
        return jsonify({
            'success': True,
            'overall_statistics': {
                'total_spd_documents': total_spd_docs,
                'total_bps_documents': total_bps_docs,
                'processed_spd_documents': processed_spd_docs,
                'processed_bps_documents': processed_bps_docs,
                'processing_success_rate': {
                    'spd': (processed_spd_docs / total_spd_docs * 100) if total_spd_docs > 0 else 0,
                    'bps': (processed_bps_docs / total_bps_docs * 100) if total_bps_docs > 0 else 0
                }
            },
            'plan_statistics': plan_stats
        })
        
    except Exception as e:
        logger.error(f"Error getting statistics: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve statistics'
        }), 500


"""
SmartSPD v2 - Chat API Routes
============================

This module provides API endpoints for the Smart Agent chat functionality,
including query processing, conversation management, and feedback collection.
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, List
import uuid

from flask import Blueprint, request, jsonify, current_app

from src.models.smartspd_models import (
    QueryRecord, HealthPlan, SmartSPDUser, QueryStatus, 
    ConfidenceLevel, db
)
from src.services.rag_service import RAGService

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create blueprint
chat_bp = Blueprint('chat', __name__)

def get_rag_service():
    """Get or create RAG service instance."""
    # Get configuration from environment
    openai_api_key = os.environ.get('OPENAI_API_KEY')
    neo4j_config = None
    
    if all([
        os.environ.get('NEO4J_URI'),
        os.environ.get('NEO4J_USER'),
        os.environ.get('NEO4J_PASSWORD')
    ]):
        neo4j_config = {
            'uri': os.environ.get('NEO4J_URI'),
            'user': os.environ.get('NEO4J_USER'),
            'password': os.environ.get('NEO4J_PASSWORD')
        }
    
    return RAGService(openai_api_key, neo4j_config)

@chat_bp.route('/query', methods=['POST'])
def process_query():
    """Process a user query and return Smart Agent response."""
    try:
        # Get request data
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        query_text = data.get('query')
        health_plan_id = data.get('health_plan_id')
        user_id = data.get('user_id', 'anonymous')  # Default for demo
        session_id = data.get('session_id')
        
        if not query_text:
            return jsonify({
                'success': False,
                'error': 'Query text is required'
            }), 400
        
        if not health_plan_id:
            return jsonify({
                'success': False,
                'error': 'Health plan ID is required'
            }), 400
        
        # Verify health plan exists
        health_plan = HealthPlan.query.get(health_plan_id)
        if not health_plan:
            return jsonify({
                'success': False,
                'error': 'Health plan not found'
            }), 404
        
        # Initialize RAG service
        rag_service = get_rag_service()
        
        # Process the query
        query_record = rag_service.process_query(
            query=query_text,
            health_plan_id=health_plan_id,
            user_id=user_id,
            session_id=session_id
        )
        
        # Format response
        response_data = {
            'success': True,
            'query_id': query_record.id,
            'response': query_record.response_text,
            'confidence_level': query_record.confidence_level,
            'sources': query_record.sources_used,
            'response_time_ms': query_record.response_time_ms,
            'session_id': query_record.session_id,
            'timestamp': query_record.created_at.isoformat()
        }
        
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"Error processing query: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to process query'
        }), 500

@chat_bp.route('/conversations/<session_id>', methods=['GET'])
def get_conversation(session_id):
    """Get conversation history for a session."""
    try:
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        # Get queries for this session
        queries_query = QueryRecord.query.filter_by(session_id=session_id).order_by(QueryRecord.created_at.asc())
        queries_paginated = queries_query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        # Format conversation data
        conversation = []
        for query in queries_paginated.items:
            query_data = {
                'id': query.id,
                'query': query.query_text,
                'response': query.response_text,
                'confidence_level': query.confidence_level,
                'sources': query.sources_used,
                'response_time_ms': query.response_time_ms,
                'status': query.status,
                'timestamp': query.created_at.isoformat(),
                'feedback': {
                    'rating': query.feedback_rating,
                    'comment': query.feedback_comment
                } if query.feedback_rating else None
            }
            conversation.append(query_data)
        
        return jsonify({
            'success': True,
            'session_id': session_id,
            'conversation': conversation,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': queries_paginated.total,
                'pages': queries_paginated.pages,
                'has_next': queries_paginated.has_next,
                'has_prev': queries_paginated.has_prev
            }
        })
        
    except Exception as e:
        logger.error(f"Error getting conversation: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve conversation'
        }), 500

@chat_bp.route('/sessions', methods=['GET'])
def get_user_sessions():
    """Get all chat sessions for a user."""
    try:
        user_id = request.args.get('user_id', 'anonymous')
        health_plan_id = request.args.get('health_plan_id')
        
        # Build query
        query = QueryRecord.query.filter_by(user_id=user_id)
        if health_plan_id:
            query = query.filter_by(health_plan_id=health_plan_id)
        
        # Get unique sessions with latest activity
        sessions_data = db.session.query(
            QueryRecord.session_id,
            db.func.max(QueryRecord.created_at).label('last_activity'),
            db.func.count(QueryRecord.id).label('message_count'),
            QueryRecord.health_plan_id
        ).filter_by(user_id=user_id)
        
        if health_plan_id:
            sessions_data = sessions_data.filter_by(health_plan_id=health_plan_id)
        
        sessions_data = sessions_data.group_by(
            QueryRecord.session_id, QueryRecord.health_plan_id
        ).order_by(db.func.max(QueryRecord.created_at).desc()).all()
        
        # Format sessions
        sessions = []
        for session in sessions_data:
            # Get health plan info
            health_plan = HealthPlan.query.get(session.health_plan_id)
            
            # Get first query for preview
            first_query = QueryRecord.query.filter_by(
                session_id=session.session_id
            ).order_by(QueryRecord.created_at.asc()).first()
            
            session_data = {
                'session_id': session.session_id,
                'last_activity': session.last_activity.isoformat(),
                'message_count': session.message_count,
                'health_plan': {
                    'id': health_plan.id,
                    'name': health_plan.plan_name,
                    'code': health_plan.plan_code
                } if health_plan else None,
                'preview': first_query.query_text[:100] + '...' if first_query and len(first_query.query_text) > 100 else first_query.query_text if first_query else ''
            }
            sessions.append(session_data)
        
        return jsonify({
            'success': True,
            'sessions': sessions
        })
        
    except Exception as e:
        logger.error(f"Error getting user sessions: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve sessions'
        }), 500

@chat_bp.route('/feedback', methods=['POST'])
def submit_feedback():
    """Submit feedback for a query response."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'error': 'No data provided'
            }), 400
        
        query_id = data.get('query_id')
        rating = data.get('rating')
        comment = data.get('comment', '')
        
        if not query_id:
            return jsonify({
                'success': False,
                'error': 'Query ID is required'
            }), 400
        
        if not rating or not isinstance(rating, int) or rating < 1 or rating > 5:
            return jsonify({
                'success': False,
                'error': 'Rating must be an integer between 1 and 5'
            }), 400
        
        # Initialize RAG service and submit feedback
        rag_service = get_rag_service()
        success = rag_service.add_feedback(query_id, rating, comment)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Feedback submitted successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to submit feedback'
            }), 500
        
    except Exception as e:
        logger.error(f"Error submitting feedback: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to submit feedback'
        }), 500

@chat_bp.route('/suggested-questions', methods=['GET'])
def get_suggested_questions():
    """Get suggested questions for a health plan."""
    try:
        health_plan_id = request.args.get('health_plan_id')
        
        if not health_plan_id:
            return jsonify({
                'success': False,
                'error': 'Health plan ID is required'
            }), 400
        
        # Verify health plan exists
        health_plan = HealthPlan.query.get(health_plan_id)
        if not health_plan:
            return jsonify({
                'success': False,
                'error': 'Health plan not found'
            }), 404
        
        # Generate suggested questions based on plan type and available documents
        suggested_questions = generate_suggested_questions(health_plan)
        
        return jsonify({
            'success': True,
            'health_plan': {
                'id': health_plan.id,
                'name': health_plan.plan_name,
                'type': health_plan.plan_type
            },
            'suggested_questions': suggested_questions
        })
        
    except Exception as e:
        logger.error(f"Error getting suggested questions: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve suggested questions'
        }), 500

def generate_suggested_questions(health_plan: HealthPlan) -> List[Dict[str, Any]]:
    """Generate suggested questions based on health plan characteristics."""
    questions = []
    
    # Base questions for all plans
    base_questions = [
        {
            'category': 'Coverage',
            'question': 'What medical services are covered under this plan?',
            'description': 'Learn about covered medical benefits and services'
        },
        {
            'category': 'Costs',
            'question': 'What are my deductibles and copays?',
            'description': 'Understand your out-of-pocket costs'
        },
        {
            'category': 'Providers',
            'question': 'How do I find in-network providers?',
            'description': 'Locate healthcare providers in your network'
        },
        {
            'category': 'Claims',
            'question': 'How do I submit a claim?',
            'description': 'Learn the claims submission process'
        }
    ]
    
    questions.extend(base_questions)
    
    # Plan type specific questions
    if health_plan.plan_type == 'DPC':
        dpc_questions = [
            {
                'category': 'DPC Specific',
                'question': 'What services are included in my DPC membership?',
                'description': 'Understand your Direct Primary Care benefits'
            },
            {
                'category': 'DPC Specific',
                'question': 'How do I access my primary care physician?',
                'description': 'Learn how to contact and schedule with your DPC provider'
            }
        ]
        questions.extend(dpc_questions)
    
    elif health_plan.plan_type == 'PPO':
        ppo_questions = [
            {
                'category': 'PPO Specific',
                'question': 'Can I see specialists without a referral?',
                'description': 'Understand specialist access in your PPO plan'
            },
            {
                'category': 'PPO Specific',
                'question': 'What is the difference between in-network and out-of-network costs?',
                'description': 'Learn about network cost differences'
            }
        ]
        questions.extend(ppo_questions)
    
    elif health_plan.plan_type == 'HMO':
        hmo_questions = [
            {
                'category': 'HMO Specific',
                'question': 'Do I need a referral to see a specialist?',
                'description': 'Understand referral requirements in your HMO'
            },
            {
                'category': 'HMO Specific',
                'question': 'Who is my primary care physician?',
                'description': 'Find information about your assigned PCP'
            }
        ]
        questions.extend(hmo_questions)
    
    # Add questions based on available documents
    if health_plan.bps_data:
        questions.append({
            'category': 'Benefits',
            'question': 'What are my prescription drug benefits?',
            'description': 'Learn about your pharmacy coverage'
        })
        
        questions.append({
            'category': 'Benefits',
            'question': 'What preventive care is covered at 100%?',
            'description': 'Discover your preventive care benefits'
        })
    
    return questions

@chat_bp.route('/analytics', methods=['GET'])
def get_chat_analytics():
    """Get analytics data for chat usage."""
    try:
        # Get date range parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        health_plan_id = request.args.get('health_plan_id')
        
        # Build base query
        query = QueryRecord.query
        
        if health_plan_id:
            query = query.filter_by(health_plan_id=health_plan_id)
        
        if start_date:
            try:
                start_dt = datetime.fromisoformat(start_date)
                query = query.filter(QueryRecord.created_at >= start_dt)
            except ValueError:
                pass
        
        if end_date:
            try:
                end_dt = datetime.fromisoformat(end_date)
                query = query.filter(QueryRecord.created_at <= end_dt)
            except ValueError:
                pass
        
        # Get basic statistics
        total_queries = query.count()
        completed_queries = query.filter_by(status=QueryStatus.COMPLETED.value).count()
        failed_queries = query.filter_by(status=QueryStatus.FAILED.value).count()
        
        # Get confidence level distribution
        confidence_stats = db.session.query(
            QueryRecord.confidence_level,
            db.func.count(QueryRecord.id).label('count')
        ).filter(QueryRecord.id.in_([q.id for q in query.all()])).group_by(
            QueryRecord.confidence_level
        ).all()
        
        confidence_distribution = {
            'high': 0,
            'medium': 0,
            'low': 0
        }
        
        for stat in confidence_stats:
            if stat.confidence_level in confidence_distribution:
                confidence_distribution[stat.confidence_level] = stat.count
        
        # Get average response time
        avg_response_time = db.session.query(
            db.func.avg(QueryRecord.response_time_ms)
        ).filter(QueryRecord.id.in_([q.id for q in query.all()])).scalar()
        
        # Get feedback statistics
        feedback_queries = query.filter(QueryRecord.feedback_rating.isnot(None))
        total_feedback = feedback_queries.count()
        avg_rating = db.session.query(
            db.func.avg(QueryRecord.feedback_rating)
        ).filter(QueryRecord.id.in_([q.id for q in feedback_queries.all()])).scalar()
        
        # Get rating distribution
        rating_stats = db.session.query(
            QueryRecord.feedback_rating,
            db.func.count(QueryRecord.id).label('count')
        ).filter(QueryRecord.id.in_([q.id for q in feedback_queries.all()])).group_by(
            QueryRecord.feedback_rating
        ).all()
        
        rating_distribution = {str(i): 0 for i in range(1, 6)}
        for stat in rating_stats:
            if stat.feedback_rating:
                rating_distribution[str(stat.feedback_rating)] = stat.count
        
        # Get popular queries (most common query patterns)
        # This is a simplified version - in production, you might use NLP to group similar queries
        recent_queries = query.order_by(QueryRecord.created_at.desc()).limit(100).all()
        query_keywords = {}
        
        for q in recent_queries:
            words = q.query_text.lower().split()
            for word in words:
                if len(word) > 3:  # Only count meaningful words
                    query_keywords[word] = query_keywords.get(word, 0) + 1
        
        # Get top keywords
        top_keywords = sorted(query_keywords.items(), key=lambda x: x[1], reverse=True)[:10]
        
        analytics_data = {
            'success': True,
            'period': {
                'start_date': start_date,
                'end_date': end_date,
                'health_plan_id': health_plan_id
            },
            'query_statistics': {
                'total_queries': total_queries,
                'completed_queries': completed_queries,
                'failed_queries': failed_queries,
                'success_rate': (completed_queries / total_queries * 100) if total_queries > 0 else 0
            },
            'confidence_distribution': confidence_distribution,
            'performance': {
                'average_response_time_ms': round(avg_response_time, 2) if avg_response_time else 0
            },
            'feedback': {
                'total_feedback': total_feedback,
                'average_rating': round(avg_rating, 2) if avg_rating else 0,
                'rating_distribution': rating_distribution,
                'feedback_rate': (total_feedback / total_queries * 100) if total_queries > 0 else 0
            },
            'popular_keywords': [{'keyword': k, 'count': v} for k, v in top_keywords]
        }
        
        return jsonify(analytics_data)
        
    except Exception as e:
        logger.error(f"Error getting chat analytics: {e}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve analytics'
        }), 500

@chat_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint for the chat service."""
    try:
        # Test RAG service initialization
        rag_service = get_rag_service()
        
        # Test database connection
        db.session.execute('SELECT 1')
        
        return jsonify({
            'success': True,
            'status': 'healthy',
            'services': {
                'database': 'connected',
                'rag_service': 'initialized',
                'openai': 'available' if os.environ.get('OPENAI_API_KEY') else 'not_configured',
                'neo4j': 'available' if all([
                    os.environ.get('NEO4J_URI'),
                    os.environ.get('NEO4J_USER'),
                    os.environ.get('NEO4J_PASSWORD')
                ]) else 'not_configured'
            }
        })
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return jsonify({
            'success': False,
            'status': 'unhealthy',
            'error': str(e)
        }), 500


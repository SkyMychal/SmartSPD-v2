"""
SmartSPD v2 - Database Models
============================

This module defines the SQLAlchemy models for the SmartSPD v2 system.
"""

from datetime import datetime, date
from typing import Optional, List, Dict, Any
from enum import Enum
import uuid

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, String, Integer, DateTime, Date, Boolean, Text, JSON, ForeignKey, Float, Index
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID
from werkzeug.security import generate_password_hash, check_password_hash

# Import the db instance from the existing user model
from src.models.user import db

# Enums for type safety
class UserRole(str, Enum):
    ADMIN = "admin"
    AGENT = "agent"
    MANAGER = "manager"
    VIEWER = "viewer"

class PlanType(str, Enum):
    PPO = "PPO"
    HMO = "HMO"
    DPC = "DPC"
    HDHP = "HDHP"
    EPO = "EPO"
    POS = "POS"

class DocumentStatus(str, Enum):
    UPLOADED = "uploaded"
    PROCESSING = "processing"
    PROCESSED = "processed"
    FAILED = "failed"
    ARCHIVED = "archived"

class QueryStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class ConfidenceLevel(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

class BenefitType(str, Enum):
    MEDICAL = "medical"
    DENTAL = "dental"
    VISION = "vision"
    PRESCRIPTION = "prescription"
    MENTAL_HEALTH = "mental_health"
    PREVENTIVE = "preventive"

# ================================
# Enhanced User Model
# ================================

class SmartSPDUser(db.Model):
    """Enhanced user model for SmartSPD v2."""
    __tablename__ = "smartspd_users"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    role = Column(String(20), nullable=False, default=UserRole.AGENT.value)
    is_active = Column(Boolean, default=True)
    last_login = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    tpa_access = relationship("UserTPAAccess", back_populates="user", cascade="all, delete-orphan")
    queries = relationship("QueryRecord", back_populates="user")
    
    def set_password(self, password: str):
        """Set password hash."""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password: str) -> bool:
        """Check password against hash."""
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f"<SmartSPDUser {self.username}>"

class TPAClient(db.Model):
    """TPA Client model representing third-party administrators."""
    __tablename__ = "tpa_clients"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), nullable=False, index=True)
    code = Column(String(50), unique=True, nullable=False, index=True)
    contact_email = Column(String(255))
    contact_phone = Column(String(50))
    address = Column(JSON)
    settings = Column(JSON, default=dict)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    health_plans = relationship("HealthPlan", back_populates="tpa_client", cascade="all, delete-orphan")
    user_access = relationship("UserTPAAccess", back_populates="tpa_client")
    
    def __repr__(self):
        return f"<TPAClient {self.name}>"

class UserTPAAccess(db.Model):
    """Junction table for user access to TPA clients."""
    __tablename__ = "user_tpa_access"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("smartspd_users.id"), nullable=False)
    tpa_client_id = Column(String(36), ForeignKey("tpa_clients.id"), nullable=False)
    access_level = Column(String(20), default="read")  # read, write, admin
    granted_at = Column(DateTime, default=datetime.utcnow)
    granted_by = Column(String(36), ForeignKey("smartspd_users.id"))
    
    # Relationships
    user = relationship("SmartSPDUser", back_populates="tpa_access", foreign_keys=[user_id])
    tpa_client = relationship("TPAClient", back_populates="user_access")
    
    __table_args__ = (
        Index('idx_user_tpa_access', 'user_id', 'tpa_client_id'),
    )

class HealthPlan(db.Model):
    """Health plan model representing specific insurance plans."""
    __tablename__ = "health_plans"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    tpa_client_id = Column(String(36), ForeignKey("tpa_clients.id"), nullable=False)
    plan_name = Column(String(255), nullable=False, index=True)
    plan_code = Column(String(50), nullable=False)
    plan_type = Column(String(20), nullable=False)  # PPO, HMO, DPC, etc.
    effective_date = Column(Date, nullable=False)
    termination_date = Column(Date)
    description = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    tpa_client = relationship("TPAClient", back_populates="health_plans")
    spd_documents = relationship("SPDDocument", back_populates="health_plan", cascade="all, delete-orphan")
    bps_data = relationship("BPSData", back_populates="health_plan", cascade="all, delete-orphan")
    queries = relationship("QueryRecord", back_populates="health_plan")
    
    __table_args__ = (
        Index('idx_plan_tpa_code', 'tpa_client_id', 'plan_code'),
    )
    
    def __repr__(self):
        return f"<HealthPlan {self.plan_name}>"

class SPDDocument(db.Model):
    """SPD (Summary Plan Description) document model."""
    __tablename__ = "spd_documents"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    health_plan_id = Column(String(36), ForeignKey("health_plans.id"), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_size = Column(Integer)
    file_hash = Column(String(64), index=True)  # SHA-256 hash
    mime_type = Column(String(100))
    upload_date = Column(DateTime, default=datetime.utcnow)
    processed_date = Column(DateTime)
    processing_status = Column(String(20), default=DocumentStatus.UPLOADED.value)
    processing_error = Column(Text)
    chunk_count = Column(Integer, default=0)
    page_count = Column(Integer)
    doc_metadata = Column(JSON, default=dict)  # Renamed from 'metadata'
    version = Column(Integer, default=1)
    is_current = Column(Boolean, default=True)
    uploaded_by = Column(String(36), ForeignKey("smartspd_users.id"))
    
    # Relationships
    health_plan = relationship("HealthPlan", back_populates="spd_documents")
    chunks = relationship("DocumentChunk", back_populates="spd_document", cascade="all, delete-orphan")
    
    __table_args__ = (
        Index('idx_spd_plan_status', 'health_plan_id', 'processing_status'),
        Index('idx_spd_hash', 'file_hash'),
    )
    
    def __repr__(self):
        return f"<SPDDocument {self.file_name}>"

class BPSData(db.Model):
    """BPS (Benefits Plan Specification) data model for Excel files."""
    __tablename__ = "bps_data"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    health_plan_id = Column(String(36), ForeignKey("health_plans.id"), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_hash = Column(String(64), index=True)
    upload_date = Column(DateTime, default=datetime.utcnow)
    processed_date = Column(DateTime)
    processing_status = Column(String(20), default=DocumentStatus.UPLOADED.value)
    worksheet_count = Column(Integer, default=0)
    structured_data = Column(JSON, default=dict)
    benefits_summary = Column(JSON, default=dict)
    version = Column(Integer, default=1)
    is_current = Column(Boolean, default=True)
    uploaded_by = Column(String(36), ForeignKey("smartspd_users.id"))
    
    # Relationships
    health_plan = relationship("HealthPlan", back_populates="bps_data")
    
    __table_args__ = (
        Index('idx_bps_plan_status', 'health_plan_id', 'processing_status'),
    )
    
    def __repr__(self):
        return f"<BPSData {self.file_name}>"

class DocumentChunk(db.Model):
    """Document chunk model for storing processed text segments."""
    __tablename__ = "document_chunks"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    spd_document_id = Column(String(36), ForeignKey("spd_documents.id"), nullable=False)
    chunk_index = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    content_type = Column(String(50), default="text")  # text, table, heading
    page_number = Column(Integer)
    section_title = Column(String(255))
    word_count = Column(Integer)
    char_count = Column(Integer)
    embedding_vector = Column(JSON)  # Store as JSON array
    chunk_metadata = Column(JSON, default=dict)  # Renamed from 'metadata'
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    spd_document = relationship("SPDDocument", back_populates="chunks")
    
    __table_args__ = (
        Index('idx_chunk_document_index', 'spd_document_id', 'chunk_index'),
        Index('idx_chunk_page', 'page_number'),
    )
    
    def __repr__(self):
        return f"<DocumentChunk {self.chunk_index}>"

class QueryRecord(db.Model):
    """Query record model for storing user queries and responses."""
    __tablename__ = "query_records"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("smartspd_users.id"), nullable=False)
    health_plan_id = Column(String(36), ForeignKey("health_plans.id"), nullable=False)
    session_id = Column(String(255), index=True)
    query_text = Column(Text, nullable=False)
    response_text = Column(Text)
    confidence_level = Column(String(20))
    response_time_ms = Column(Integer)
    sources_used = Column(JSON, default=list)
    feedback_rating = Column(Integer)  # 1-5 scale
    feedback_comment = Column(Text)
    status = Column(String(20), default=QueryStatus.PENDING.value)
    error_message = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)
    
    # Relationships
    user = relationship("SmartSPDUser", back_populates="queries")
    health_plan = relationship("HealthPlan", back_populates="queries")
    
    __table_args__ = (
        Index('idx_query_user_plan', 'user_id', 'health_plan_id'),
        Index('idx_query_session', 'session_id'),
        Index('idx_query_created', 'created_at'),
    )
    
    def __repr__(self):
        return f"<QueryRecord {self.id}>"

class AuditLog(db.Model):
    """Audit log model for compliance and security tracking."""
    __tablename__ = "audit_logs"
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String(36), ForeignKey("smartspd_users.id"))
    action = Column(String(100), nullable=False, index=True)
    resource_type = Column(String(50), nullable=False)
    resource_id = Column(String(255))
    details = Column(JSON, default=dict)
    ip_address = Column(String(45))
    user_agent = Column(String(500))
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    
    __table_args__ = (
        Index('idx_audit_user_action', 'user_id', 'action'),
        Index('idx_audit_resource', 'resource_type', 'resource_id'),
    )
    
    def __repr__(self):
        return f"<AuditLog {self.action}>"

# ================================
# Knowledge Graph Models (for Neo4j integration)
# ================================

class BenefitNode:
    """Benefit node model for knowledge graph (Neo4j)."""
    
    def __init__(self, benefit_id: str, benefit_type: str, name: str, 
                 description: str = None, amount: float = None, 
                 percentage: float = None, frequency: str = None):
        self.id = benefit_id
        self.type = benefit_type
        self.name = name
        self.description = description
        self.amount = amount
        self.percentage = percentage
        self.frequency = frequency
        self.conditions = []
        self.exclusions = []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for Neo4j storage."""
        return {
            'id': self.id,
            'type': self.type,
            'name': self.name,
            'description': self.description,
            'amount': self.amount,
            'percentage': self.percentage,
            'frequency': self.frequency,
            'conditions': self.conditions,
            'exclusions': self.exclusions
        }

class PlanBenefitRelationship:
    """Relationship between plan and benefit in knowledge graph."""
    
    def __init__(self, plan_id: str, benefit_id: str, relationship_type: str,
                 effective_date: date = None, termination_date: date = None,
                 conditions: Dict[str, Any] = None):
        self.plan_id = plan_id
        self.benefit_id = benefit_id
        self.relationship_type = relationship_type
        self.effective_date = effective_date
        self.termination_date = termination_date
        self.conditions = conditions or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for Neo4j storage."""
        return {
            'plan_id': self.plan_id,
            'benefit_id': self.benefit_id,
            'relationship_type': self.relationship_type,
            'effective_date': self.effective_date.isoformat() if self.effective_date else None,
            'termination_date': self.termination_date.isoformat() if self.termination_date else None,
            'conditions': self.conditions
        }

# ================================
# Utility Functions
# ================================

def create_sample_data():
    """Create sample data for testing purposes."""
    
    # Create sample TPA client
    tpa_client = TPAClient(
        name="Sample TPA Inc.",
        code="SAMPLE_TPA",
        contact_email="contact@sampletpa.com",
        contact_phone="555-0123",
        address={
            "street": "123 Main St",
            "city": "Anytown",
            "state": "ST",
            "zip": "12345"
        }
    )
    
    # Create sample health plan
    health_plan = HealthPlan(
        tpa_client=tpa_client,
        plan_name="Sample DPC Plan",
        plan_code="DPC_001",
        plan_type=PlanType.DPC.value,
        effective_date=date(2024, 1, 1),
        description="Sample Direct Primary Care plan for testing"
    )
    
    # Create sample user
    user = SmartSPDUser(
        username="demo_agent",
        email="demo@smartspd.com",
        first_name="Demo",
        last_name="Agent",
        role=UserRole.AGENT.value
    )
    user.set_password("demo123")
    
    # Create user access to TPA
    user_access = UserTPAAccess(
        user=user,
        tpa_client=tpa_client,
        access_level="write"
    )
    
    return {
        'tpa_client': tpa_client,
        'health_plan': health_plan,
        'user': user,
        'user_access': user_access
    }

def init_database():
    """Initialize database with tables and sample data."""
    try:
        # Create all tables
        db.create_all()
        
        # Check if sample data already exists
        existing_tpa = TPAClient.query.filter_by(code="SAMPLE_TPA").first()
        if not existing_tpa:
            # Create sample data
            sample_data = create_sample_data()
            
            # Add to database
            for item in sample_data.values():
                db.session.add(item)
            
            db.session.commit()
            print("Sample data created successfully!")
        else:
            print("Sample data already exists.")
            
    except Exception as e:
        print(f"Error initializing database: {e}")
        db.session.rollback()
        raise


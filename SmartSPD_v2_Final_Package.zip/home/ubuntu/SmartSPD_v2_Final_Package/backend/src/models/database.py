"""
SmartSPD v2 - Simple Database Connection
Provides basic database functionality for testing without complex relationships.
"""

import sqlite3
import os
from typing import Dict, Any, Optional

class SimpleDatabase:
    def __init__(self, db_path: str = None):
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), '..', 'data', 'smartspd.db')
        
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.init_tables()
    
    def get_connection(self):
        """Get database connection."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # Enable dict-like access
        return conn
    
    def init_tables(self):
        """Initialize database tables."""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                name TEXT NOT NULL,
                organization TEXT,
                role TEXT DEFAULT 'member',
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login_at TIMESTAMP
            )
        ''')
        
        # User sessions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_sessions (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                session_token TEXT UNIQUE NOT NULL,
                ip_address TEXT,
                user_agent TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP NOT NULL,
                is_active BOOLEAN DEFAULT 1,
                ended_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Health plans table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS health_plans (
                id TEXT PRIMARY KEY,
                plan_name TEXT NOT NULL,
                plan_code TEXT UNIQUE NOT NULL,
                plan_type TEXT,
                organization TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Chat queries table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat_queries (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                health_plan_id TEXT NOT NULL,
                session_id TEXT,
                query_text TEXT NOT NULL,
                response_text TEXT,
                confidence_level TEXT,
                response_time_ms INTEGER,
                sources_json TEXT,
                feedback_rating INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (health_plan_id) REFERENCES health_plans (id)
            )
        ''')
        
        conn.commit()
        conn.close()
        
        # Insert demo data
        self.insert_demo_data()
    
    def insert_demo_data(self):
        """Insert demo data for testing."""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Check if demo data already exists
        cursor.execute("SELECT COUNT(*) FROM health_plans WHERE id = 'demo-plan-456'")
        if cursor.fetchone()[0] > 0:
            conn.close()
            return
        
        # Insert demo health plan
        cursor.execute('''
            INSERT OR IGNORE INTO health_plans 
            (id, plan_name, plan_code, plan_type, organization, is_active)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            'demo-plan-456',
            'Demo Comprehensive Health Plan',
            'DEMO-001',
            'PPO',
            'Demo Organization',
            1
        ))
        
        conn.commit()
        conn.close()

# Global database instance
db = SimpleDatabase()

def get_db_session():
    """Get database session (simplified for testing)."""
    return db


# SmartSPD v2 Deployment Guide

## 🚀 Quick Deployment

### Option 1: Local Development

1. **Clone/Copy the project files**
   ```bash
   # Copy the SmartSPD_v2_Final_Package to your desired location
   cp -r SmartSPD_v2_Final_Package /path/to/your/workspace/smartspd-v2
   cd /path/to/your/workspace/smartspd-v2
   ```

2. **Backend Setup**
   ```bash
   cd backend
   source venv/bin/activate
   pip install -r requirements.txt
   python src/main.py
   ```

3. **Frontend Setup** (in a new terminal)
   ```bash
   cd frontend
   pnpm install
   pnpm run dev --host
   ```

4. **Access the application**
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:5000

### Option 2: GitLab Deployment

1. **Create GitLab Repository**
   ```bash
   git init
   git add .
   git commit -m "Initial SmartSPD v2 commit"
   git remote add origin https://gitlab.com/your-username/smartspd-v2.git
   git push -u origin main
   ```

2. **GitLab CI/CD Configuration**
   Create `.gitlab-ci.yml`:
   ```yaml
   stages:
     - build
     - test
     - deploy

   variables:
     NODE_VERSION: "20"
     PYTHON_VERSION: "3.11"

   build_frontend:
     stage: build
     image: node:${NODE_VERSION}
     script:
       - cd frontend
       - npm install -g pnpm
       - pnpm install
       - pnpm run build
     artifacts:
       paths:
         - frontend/dist/

   build_backend:
     stage: build
     image: python:${PYTHON_VERSION}
     script:
       - cd backend
       - pip install -r requirements.txt
       - python -m pytest tests/ || echo "No tests found"
     artifacts:
       paths:
         - backend/

   deploy_production:
     stage: deploy
     image: python:${PYTHON_VERSION}
     script:
       - cd backend
       - pip install -r requirements.txt
       - cp -r ../frontend/dist/* src/static/
       - gunicorn -w 4 -b 0.0.0.0:$PORT src.main:app
     only:
       - main
   ```

### Option 3: Docker Deployment

1. **Create Dockerfile for Backend**
   ```dockerfile
   # backend/Dockerfile
   FROM python:3.11-slim

   WORKDIR /app
   COPY requirements.txt .
   RUN pip install -r requirements.txt

   COPY src/ ./src/
   COPY static/ ./src/static/

   EXPOSE 5000
   CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "src.main:app"]
   ```

2. **Create docker-compose.yml**
   ```yaml
   version: '3.8'
   services:
     smartspd-backend:
       build: ./backend
       ports:
         - "5000:5000"
       environment:
         - SECRET_KEY=your-secret-key
         - JWT_SECRET_KEY=your-jwt-secret
       volumes:
         - ./data:/app/data

     smartspd-frontend:
       image: nginx:alpine
       ports:
         - "80:80"
       volumes:
         - ./frontend/dist:/usr/share/nginx/html
       depends_on:
         - smartspd-backend
   ```

3. **Deploy with Docker**
   ```bash
   # Build frontend
   cd frontend && pnpm run build && cd ..
   
   # Copy frontend build to backend static
   cp -r frontend/dist/* backend/src/static/
   
   # Deploy with Docker Compose
   docker-compose up -d
   ```

## 🔧 Environment Configuration

### Required Environment Variables

```bash
# Security (Required)
SECRET_KEY=your-flask-secret-key-change-in-production
JWT_SECRET_KEY=your-jwt-secret-key-change-in-production

# AI Services (Optional - for full functionality)
OPENAI_API_KEY=your-openai-api-key

# Database (Optional - defaults to SQLite)
DATABASE_URL=sqlite:///data/smartspd.db

# Cache Settings (Optional)
CACHE_TTL_SECONDS=3600
MAX_MEMORY_CACHE_ITEMS=1000

# Logging (Optional)
LOG_LEVEL=INFO
LOG_FILE=logs/smartspd.log
```

### Production Environment Setup

1. **Create .env file**
   ```bash
   cd backend
   cp .env.example .env
   # Edit .env with your production values
   ```

2. **Secure the application**
   ```bash
   # Generate secure keys
   python -c "import secrets; print('SECRET_KEY=' + secrets.token_hex(32))"
   python -c "import secrets; print('JWT_SECRET_KEY=' + secrets.token_hex(32))"
   ```

## 🗄️ Database Setup

### SQLite (Default)
No additional setup required. Database file will be created automatically.

### PostgreSQL (Production)
1. **Install PostgreSQL**
2. **Create database**
   ```sql
   CREATE DATABASE smartspd;
   CREATE USER smartspd_user WITH PASSWORD 'your_password';
   GRANT ALL PRIVILEGES ON DATABASE smartspd TO smartspd_user;
   ```
3. **Update environment**
   ```bash
   DATABASE_URL=postgresql://smartspd_user:your_password@localhost/smartspd
   ```

## 🔐 Security Checklist

### Production Security
- [ ] Change default SECRET_KEY and JWT_SECRET_KEY
- [ ] Use HTTPS in production
- [ ] Configure CORS properly
- [ ] Set up rate limiting
- [ ] Enable audit logging
- [ ] Use environment variables for secrets
- [ ] Regular security updates

### HIPAA Compliance
- [ ] Encrypt data at rest
- [ ] Encrypt data in transit
- [ ] Implement access controls
- [ ] Enable audit logging
- [ ] Regular security assessments
- [ ] Staff training on data handling

## 📊 Monitoring & Logging

### Application Monitoring
```python
# Add to backend/src/main.py
import logging
from logging.handlers import RotatingFileHandler

if not app.debug:
    file_handler = RotatingFileHandler('logs/smartspd.log', maxBytes=10240, backupCount=10)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
```

### Performance Monitoring
- Monitor response times
- Track cache hit rates
- Monitor database performance
- Set up alerts for errors

## 🚀 Scaling Considerations

### Horizontal Scaling
- Use load balancer (nginx, HAProxy)
- Deploy multiple backend instances
- Shared database and cache
- CDN for static assets

### Vertical Scaling
- Increase server resources
- Optimize database queries
- Implement connection pooling
- Use async processing for heavy tasks

## 🔄 Backup & Recovery

### Database Backup
```bash
# SQLite
cp data/smartspd.db backups/smartspd_$(date +%Y%m%d_%H%M%S).db

# PostgreSQL
pg_dump smartspd > backups/smartspd_$(date +%Y%m%d_%H%M%S).sql
```

### Application Backup
```bash
# Full application backup
tar -czf backups/smartspd_full_$(date +%Y%m%d_%H%M%S).tar.gz \
  backend/ frontend/ data/ logs/
```

## 🐛 Troubleshooting

### Common Issues

1. **Frontend not connecting to backend**
   - Check CORS configuration
   - Verify backend is running on correct port
   - Check network connectivity

2. **Authentication errors**
   - Verify JWT_SECRET_KEY is set
   - Check token expiration
   - Validate user credentials

3. **Database connection issues**
   - Check DATABASE_URL format
   - Verify database server is running
   - Check connection permissions

4. **Performance issues**
   - Monitor cache hit rates
   - Check database query performance
   - Review application logs

### Debug Mode
```bash
# Enable debug mode (development only)
export FLASK_DEBUG=1
python src/main.py
```

### Log Analysis
```bash
# View recent logs
tail -f logs/smartspd.log

# Search for errors
grep ERROR logs/smartspd.log

# Monitor API requests
grep "POST\|GET" logs/smartspd.log
```

## 📞 Support

For deployment assistance:
- Technical Documentation: See README.md
- Architecture Details: See docs/smartspd_v2_architecture.md
- API Reference: http://localhost:5000/api/health

---

**SmartSPD v2 Deployment Guide** - Get your AI health plan assistant running in production.

*BeneSense AI | Version 2.0.0*


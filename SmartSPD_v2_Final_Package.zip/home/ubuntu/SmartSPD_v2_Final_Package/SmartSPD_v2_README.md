# SmartSPD v2 - Advanced AI Health Plan Assistant

## 🚀 Overview

SmartSPD v2 is a next-generation AI-powered health plan assistant that transforms customer service operations through advanced RAG (Retrieval-Augmented Generation) technology, intelligent document processing, and natural language understanding.

### Key Features

- **Advanced RAG Technology**: Combines semantic and keyword search for precise, contextual answers
- **Intelligent Document Processing**: Automatically processes SPD and BPS documents with smart chunking
- **Multi-Role Support**: Tailored experiences for agents, members, HR managers, and brokers
- **Real-time Chat Interface**: iPhone-style messaging with instant responses
- **Enterprise Security**: HIPAA compliant with role-based access control
- **Performance Monitoring**: Built-in analytics and caching for optimal performance

## 🏗️ Architecture

### Backend (Flask API)
- **Authentication Service**: JWT-based auth with role-based permissions
- **Document Processing**: Advanced PDF/Excel parsing with context preservation
- **RAG Service**: Hybrid search combining vector and keyword matching
- **Caching Layer**: Multi-tier caching for performance optimization
- **Knowledge Graph**: Structured benefit relationships

### Frontend (React)
- **Landing Page**: Professional marketing interface
- **Authentication Modal**: Secure login/registration
- **Chat Interface**: Real-time messaging with Smart Agent
- **Responsive Design**: Mobile-first approach
- **Role-based UI**: Customized experience per user type

## 📦 Project Structure

```
smartspd-v2/
├── src/
│   ├── models/
│   │   ├── database.py          # Database connection and models
│   │   └── smartspd_models.py   # Advanced data models
│   ├── services/
│   │   ├── auth_service.py      # Authentication & authorization
│   │   ├── cache_service.py     # Multi-tier caching
│   │   ├── document_processor.py # PDF/Excel processing
│   │   ├── knowledge_graph.py   # Graph relationships
│   │   └── rag_service.py       # RAG implementation
│   ├── routes/
│   │   ├── auth.py             # Authentication endpoints
│   │   ├── chat.py             # Chat API
│   │   └── documents.py        # Document management
│   └── main.py                 # Flask application entry point
├── venv/                       # Python virtual environment
└── requirements.txt            # Python dependencies

smartspd-v2-frontend/
├── src/
│   ├── components/
│   │   ├── AuthModal.jsx       # Authentication interface
│   │   ├── ChatInterface.jsx   # Chat messaging
│   │   └── LandingPage.jsx     # Marketing page
│   ├── assets/                 # Logos and images
│   └── App.jsx                 # Main React component
├── package.json                # Node.js dependencies
└── index.html                  # Entry HTML file
```

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Node.js 20+
- Git

### Backend Setup

1. **Navigate to backend directory**
   ```bash
   cd smartspd-v2
   ```

2. **Activate virtual environment**
   ```bash
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set environment variables**
   ```bash
   export SECRET_KEY="your-secret-key"
   export JWT_SECRET_KEY="your-jwt-secret"
   export OPENAI_API_KEY="your-openai-key"  # Optional for full functionality
   ```

5. **Start the backend server**
   ```bash
   python src/main.py
   ```

   The API will be available at `http://localhost:5000`

### Frontend Setup

1. **Navigate to frontend directory**
   ```bash
   cd smartspd-v2-frontend
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Start the development server**
   ```bash
   pnpm run dev --host
   ```

   The frontend will be available at `http://localhost:5173`

## 🔐 Authentication

SmartSPD v2 includes built-in demo accounts for testing:

| Role | Email | Password | Permissions |
|------|-------|----------|-------------|
| Customer Service Agent | agent@demo.com | demo123 | Read, Write |
| Plan Member | member@demo.com | demo123 | Read |
| HR Manager | hr@demo.com | demo123 | Read, Write |
| Broker | broker@demo.com | demo123 | Read |

## 📊 API Endpoints

### Authentication
- `POST /api/auth/login` - User authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/logout` - Session termination
- `POST /api/auth/verify` - Session verification

### Chat
- `POST /api/chat/query` - Send chat message
- `GET /api/chat/history` - Get conversation history
- `POST /api/chat/feedback` - Submit feedback

### Documents
- `POST /api/documents/upload` - Upload SPD/BPS documents
- `GET /api/documents/list` - List processed documents
- `DELETE /api/documents/{id}` - Remove document

### Health Check
- `GET /api/health` - API status and version

## 🎯 Key Improvements from v1

### Enhanced Architecture
- **Modular Design**: Clean separation of concerns
- **Advanced RAG**: Hybrid search with confidence scoring
- **Caching Layer**: Multi-tier caching for performance
- **Role-based Access**: Granular permission system

### Better User Experience
- **Professional UI**: Modern, responsive design
- **Real-time Chat**: Instant messaging interface
- **Source Attribution**: Clear document references
- **Confidence Indicators**: Response reliability scoring

### Enterprise Features
- **HIPAA Compliance**: Enterprise-grade security
- **Performance Monitoring**: Built-in analytics
- **Scalable Architecture**: Ready for production deployment
- **Comprehensive Logging**: Detailed audit trails

## 🔧 Configuration

### Environment Variables

```bash
# Security
SECRET_KEY=your-flask-secret-key
JWT_SECRET_KEY=your-jwt-secret-key

# AI Services (Optional)
OPENAI_API_KEY=your-openai-api-key

# Database (Optional - defaults to SQLite)
DATABASE_URL=sqlite:///smartspd.db

# Cache Settings (Optional)
CACHE_TTL_SECONDS=3600
MAX_MEMORY_CACHE_ITEMS=1000
```

### Database Configuration

SmartSPD v2 uses SQLite by default for simplicity. For production, configure PostgreSQL or MySQL:

```python
# In src/models/database.py
DATABASE_URL = "postgresql://user:password@localhost/smartspd"
```

## 📈 Performance Features

### Caching Strategy
- **Memory Cache**: Fast access to frequently used data
- **Disk Cache**: Persistent storage for embeddings
- **Query Cache**: Cached responses for common questions
- **Embedding Cache**: Reuse of computed vectors

### Optimization
- **Lazy Loading**: Components load on demand
- **Response Compression**: Reduced bandwidth usage
- **Connection Pooling**: Efficient database connections
- **CDN Ready**: Static asset optimization

## 🛡️ Security Features

### Authentication & Authorization
- **JWT Tokens**: Secure session management
- **Password Hashing**: bcrypt encryption
- **Role-based Access**: Granular permissions
- **Session Management**: Automatic expiration

### Data Protection
- **HIPAA Compliance**: Healthcare data standards
- **Input Validation**: SQL injection prevention
- **CORS Configuration**: Cross-origin security
- **Audit Logging**: Comprehensive activity tracking

## 🚀 Deployment

### Development
```bash
# Backend
cd smartspd-v2 && source venv/bin/activate && python src/main.py

# Frontend
cd smartspd-v2-frontend && pnpm run dev --host
```

### Production
1. **Build Frontend**
   ```bash
   cd smartspd-v2-frontend && pnpm run build
   ```

2. **Copy Build to Backend**
   ```bash
   cp -r dist/* ../smartspd-v2/src/static/
   ```

3. **Deploy Backend**
   ```bash
   cd smartspd-v2 && gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
   ```

## 📝 API Documentation

### Chat Query Example

```bash
curl -X POST http://localhost:5000/api/chat/query \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "query": "What are my deductibles and copays?",
    "health_plan_id": "demo-plan-456",
    "session_id": "optional-session-id"
  }'
```

### Response Format

```json
{
  "success": true,
  "response": "Based on your Demo Comprehensive Health Plan documents...",
  "confidence_level": "high",
  "response_time_ms": 1301,
  "sources": [
    {
      "document": "Page 12 - Cost Sharing",
      "type": "spd_document"
    }
  ],
  "query_id": "uuid-string"
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is proprietary software developed for BeneSense AI.

## 🆘 Support

For technical support or questions:
- Email: support@benesense.ai
- Documentation: [Internal Wiki]
- Issues: [Project Repository]

---

**SmartSPD v2** - Transforming health plan customer service with advanced AI technology.

*Powered by BeneSense AI | Version 2.0.0*

